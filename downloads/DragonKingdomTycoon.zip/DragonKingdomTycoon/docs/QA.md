# Verification and remaining acceptance

This file distinguishes executable cloud checks from Roblox-engine checks. No Roblox Studio session was available in this Linux environment.

## Automated cloud checks

Run `python3 tools/validate.py` from the checkout after activating the toolchain and Python dependencies described in README. The runner preserves failures and writes `build/validation.json` from the current run. `python3 tools/package.py` then creates a source/assets/place ZIP with a per-file SHA256 manifest and checks the archive contents.

| Check | Evidence and limits |
|---|---|
| Domain game tests | Execute real Engine and Combat modules: starter-budget gameplay loop, habitat placement/collision, elapsed/offline gold, feed/level, eggs/hatching, full habitat storage, breeding RNG/busy checks, farming, reward idempotence, expansion and PvE rewards. Scheduled events test one second before opening, exact opening, last active second, exclusive closing, and duplicate claims. |
| Remote security | Validate allowed schemas, reject forged currency/owner/RNG, NaN/Infinity, nested/cyclic/metatable/oversized payloads; token-bucket exhaustion/refill/clock reversal. |
| Persistence adapter | Real Engine profiles against an injected UpdateAsync store: ownership lock, round trip, autosave renewal, release, failed-load safety, retry retention, corrupt/future schema, migration, expired ownership and stale-server denial. This is a mock, not live Roblox DataStore. |
| Luau source | Bytecode compilation of every source and selected strict/portable type analysis. Roblox-specific types require Studio/LSP and are not established by standalone syntax compilation. |
| Rojo place | Build actual XML/binary place, validate baked scene/model presence, remotes and scripts. File generation does not prove Roblox rendering or network replication. |
| UI mock, when retained | Runs real UI logic with explicit engine/API stand-ins; proves screen/action code paths only. It does not measure layout, touch behavior, animation appearance or performance. |
| World geometry mock | Runs actual DragonArt/WorldBuilder with geometry stand-ins: 20 distinct anatomy signatures, three growth scales, all nine biomes, stable reconciliation, stored dragons, hatch/farm slots, stud coordinates, expansions, six battle actors and replay queues. Real Roblox rendering remains unrun. |

The delivered `build/validation.json` records actual pass counts and artifact paths. Expected rejection/error tests are passing assertions about denied invalid operations; they are not hidden application failures. No test count is inferred from a zero-test command.

## Studio acceptance — not executed in cloud

| Requirement | Manual check |
|---|---|
| Initial island | Play shows decorated terrain, pond/waterfall, paths, farm/hatchery/breeding buildings, three habitats and original animated dragons immediately after profile load. |
| HUD/screens | Open every navigation item, filters/search and details; inspect empty/error/loading states, close/back/confirmation; every displayed button opens a real screen or sends a valid action. |
| Economy loop | Buy/place a Habitat, hatch and house a dragon, wait for production, collect, feed/level, farm/harvest and breed a new egg. Confirm wrong element/full slot/early claims give appropriate outcomes. |
| Inventory and upgrades | Move a dragon to storage and verify no income; move it back; upgrade a Habitat/farm/hatchery; rotate/move/remove empty Habitat; buy/place/remove decorations without overlap. |
| Battle | Select three owned dragons; check HP, turn speed, skills/cooldowns, AI, hit/victory visuals, stage unlock and exactly one reward. |
| Progression | Quest/achievement/collection/daily/event/pass rewards only once; level-gated islands unlock physically and permit placements. No Robux purchase dialog exists. |
| Multiplayer | Start two clients; verify isolated islands and read-only visiting, home return, streamed map visibility and owner-leave recovery. |
| Persistence | Published test place with API Services: leave/rejoin and server close retain resources, timestamps, team and placements. Test transient failures without overwriting existing saves. |
| Camera/input | Mouse drag/wheel/rotation and touch drag/pinch work; GUI clicks do not select map; camera bounds/reset/focus remain correct. |
| Responsive | Device Emulator and hardware: 1920×1080, 1366×768, landscape phone 16:9 and tablet; safe-area cutouts, no clipped buttons or unreadable resources. Portrait layout is not an acceptance target in the original request. |
| Art/audio | Upload/bind original PNG/audio files. Review custom mesh silhouettes/textures/rigged animation and final icon consistency before final art acceptance. |
| FPS/LOD | Measure frame time and memory on target devices with 1 and 8 players, effects high/low, zoom/visits and long sessions. Anchored procedural visuals, streaming, distance updates and pooling are implemented techniques; no FPS claim is made without measurements. |
| Error audit | Studio Output/server/client log contain no script errors; denied remote requests behave as intentional feedback. |

## Outstanding production work

- Custom skinned dragon meshes, production textures/rigged clips and final visual review remain outstanding; procedural geometry is explicitly development art.
- Local original PNG/audio files require Roblox upload/permissions and real asset ID binding. Cloud build cannot upload them without the creator workflow.
- Full Studio acceptance, live DataStore, actual touch devices and measured FPS remain unrun.
- PvP is an architectural extension point; only PvE is implemented, as requested for the initial game.
- All timers/prices are development balance values centralized in Config.Balance and Config.Dragons; production economy tuning requires playtest evidence.

These limitations prevent a “100% complete AAA release” claim, while the source and built place provide a substantial executable development project.
