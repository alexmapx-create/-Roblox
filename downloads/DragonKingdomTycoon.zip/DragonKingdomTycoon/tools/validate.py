#!/usr/bin/env python3
"""Run real cloud validation; Studio-only acceptance remains explicitly unrun."""
from pathlib import Path
import collections
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
BUILD = ROOT / 'build'
BUILD.mkdir(exist_ok=True)
REPORT = {'startedAtUnix': int(time.time()), 'checks': [], 'studioAcceptance': 'unrun', 'liveDataStore': 'unrun'}


def tool(name):
    path = shutil.which(name) or str(Path('/workspace/.roblox-tools/bin') / name)
    if not Path(path).is_file():
        raise RuntimeError(f'Missing tool: {name}; activate the Roblox toolchain first.')
    return path


def run(name, args, *, binary=False):
    result = subprocess.run(args, cwd=ROOT, capture_output=True, timeout=120)
    if result.returncode:
        sys.stdout.write(result.stdout.decode(errors='replace'))
        sys.stderr.write(result.stderr.decode(errors='replace'))
        raise subprocess.CalledProcessError(result.returncode, args)
    if not binary:
        output = result.stdout.decode() + result.stderr.decode()
        if output.strip(): print(output.strip())
    else:
        output = result.stdout
        assert output and output[0] != 0, f'{name}: no valid bytecode produced'
    REPORT['checks'].append({'name': name, 'status': 'passed'})
    return output


def require_files():
    required = [
        'src/shared/Engine.luau', 'src/shared/Domain/Combat.luau', 'src/shared/DragonArt.luau',
        'src/shared/Config/Assets.luau', 'src/server/init.server.luau',
        'src/server/Services/WorldBuilder.luau', 'src/server/Data/DataService.luau',
        'src/client/init.client.luau', 'src/client/Controllers/UI.luau',
        'src/client/Controllers/Camera.luau', 'src/client/Controllers/Animation.luau',
        'src/client/Controllers/Input.luau', 'src/client/Controllers/WorldView.luau',
        'src/models/IslandTemplate.rbxmx', 'src/world/World.rbxmx',
    ]
    for name in required: assert (ROOT / name).is_file(), f'Missing required source: {name}'
    json.loads((ROOT / 'default.project.json').read_text())
    REPORT['checks'].append({'name': 'complete project sources', 'status': 'passed'})


def inspect_place():
    path = BUILD / 'DragonKingdomTycoon.rbxlx'
    tree = ET.parse(path).getroot()
    classes = collections.Counter(item.attrib['class'] for item in tree.iter('Item'))
    sources = {item.find('Properties/*[@name="Source"]').text or ''
               for item in tree.iter('Item')
               if item.attrib['class'] in ('Script', 'LocalScript', 'ModuleScript')}
    for source in (ROOT / 'src').rglob('*.luau'):
        assert source.read_text() in sources, f'Omitted script source: {source.relative_to(ROOT)}'
    names = {item.find('Properties/string[@name="Name"]').text: item
             for item in tree.iter('Item') if item.find('Properties/string[@name="Name"]') is not None}
    for required in ('IslandTemplate', 'World', 'PlayerIslands', 'Request', 'State', 'Notice', 'GameServer', 'GameClient'):
        assert required in names, f'Missing built instance: {required}'
    assert names['Request'].attrib['class'] == 'RemoteFunction'
    assert names['State'].attrib['class'] == 'RemoteEvent'
    assert classes['Part'] >= 1000, 'Baked decorated world missing'
    REPORT['sceneClasses'] = dict(classes)
    REPORT['scriptSources'] = len(sources)
    REPORT['artifacts'] = {p.name: {'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
                           for p in (path, BUILD / 'DragonKingdomTycoon.rbxl')}
    REPORT['checks'].append({'name': 'built scene, remotes, every source embedded', 'status': 'passed'})
    print(f'PASS built place: {classes["Part"]} parts, {len(sources)} embedded script sources')


def main():
    require_files()
    luau, compiler, analyzer, rojo = map(tool, ('luau', 'luau-compile', 'luau-analyze', 'rojo'))
    source_files = sorted((ROOT / 'src').rglob('*.luau'))
    for file in source_files: run(f'compile {file.relative_to(ROOT)}', [compiler, '--binary', str(file)], binary=True)
    print(f'PASS Luau compilation: {len(source_files)} source files')
    analyze_files = ['src/shared/Engine.luau', 'src/shared/Domain/Combat.luau',
                     'src/shared/Config/Balance.luau', 'src/shared/Config/Dragons.luau',
                     'src/shared/Config/Habitats.luau', 'src/shared/Types.luau',
                     'src/server/Services/RequestGuard.luau', 'src/server/Data/DataService.luau']
    run('portable module type analysis', [analyzer, *analyze_files])
    total = 0
    for file, pattern in [('tests/engine.spec.luau', r'ENGINE TESTS: (\d+) passed'),
                          ('tests/security.spec.luau', r'Security: (\d+) tests passed'),
                          ('tests/persistence.spec.luau', r'Persistence mock: (\d+) tests passed')]:
        output = run(file, [luau, file])
        match = re.search(pattern, output)
        assert match and int(match[1]) > 0, f'{file}: tests did not finish with a positive count'
        REPORT['checks'][-1]['passedTests'] = int(match[1])
        total += int(match[1])
    if (ROOT / 'tools/ui_mock.py').exists():
        run('mock UI logic', [sys.executable, 'tools/ui_mock.py'])
    if (ROOT / 'tools/world_smoke.py').exists():
        run('mock procedural world and rendering reconciliation', [sys.executable, 'tools/world_smoke.py'])
    if (ROOT / 'tools/assets_verify.py').exists():
        run('original asset integrity and formats', [sys.executable, 'tools/assets_verify.py'])
    run('Rojo XML place build', [rojo, 'build', 'default.project.json', '--output', 'build/DragonKingdomTycoon.rbxlx'])
    run('Rojo binary place build', [rojo, 'build', 'default.project.json', '--output', 'build/DragonKingdomTycoon.rbxl'])
    run('Rojo source map', [rojo, 'sourcemap', 'default.project.json', '--output', 'build/sourcemap.json'])
    inspect_place()
    REPORT['domainSecurityPersistencePassedTests'] = total
    REPORT['status'] = 'passed_cloud_checks_studio_unrun'
    print(f'PASS {total} domain/security/persistence tests; Studio and live DataStore UNRUN')


if __name__ == '__main__':
    exit_code = 0
    try:
        main()
    except subprocess.CalledProcessError as error:
        REPORT['status'] = 'failed'
        REPORT['failure'] = str(error)
        exit_code = error.returncode if error.returncode > 0 else 128 - error.returncode
    except Exception as error:
        REPORT['status'] = 'failed'
        REPORT['failure'] = str(error)
        print('FAILED:', error, file=sys.stderr)
        exit_code = 1
    REPORT['finishedAtUnix'] = int(time.time())
    (BUILD / 'validation.json').write_text(json.dumps(REPORT, indent=2) + '\n')
    sys.exit(exit_code)
