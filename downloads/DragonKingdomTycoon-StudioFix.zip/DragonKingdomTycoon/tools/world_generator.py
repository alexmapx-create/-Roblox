#!/usr/bin/env python3
"""Bake original, asset-independent DEVELOPMENT ART into real Roblox model XML.

Only local procedural geometry is used. This is not an imported custom-mesh art pack.
Regenerate with python3 tools/world_generator.py. Both models are deterministic.
"""
from pathlib import Path
import math
import random
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
RNG = random.Random(41931)
COUNT = 0


def node(parent, cls, name):
    global COUNT
    COUNT += 1
    item = ET.SubElement(parent, 'Item', {'class': cls, 'referent': f'RBX{COUNT}'})
    props = ET.SubElement(item, 'Properties')
    ET.SubElement(props, 'string', {'name': 'Name'}).text = name
    return item, props


def prop(props, cls, name, value):
    ET.SubElement(props, cls, {'name': name}).text = str(value).lower() if isinstance(value, bool) else str(value)


def vector(props, name, xyz):
    element = ET.SubElement(props, 'Vector3', {'name': name})
    for axis, value in zip('XYZ', xyz):
        ET.SubElement(element, axis).text = f'{value:.5f}'


def rotation(rx=0, ry=0, rz=0):
    x, y, z = map(math.radians, (rx, ry, rz))
    cx, sx, cy, sy, cz, sz = math.cos(x), math.sin(x), math.cos(y), math.sin(y), math.cos(z), math.sin(z)
    return (cy*cz, -cy*sz, sy, cx*sz+sx*sy*cz, cx*cz-sx*sy*sz, -sx*cy, sx*sz-cx*sy*cz, sx*cz+cx*sy*sz, cx*cy)


def part(parent, name, pos, size, color, shape='Ball', rot=(0, 0, 0), material=272, transparency=0, collide=False):
    item, props = node(parent, 'Part' if shape != 'Wedge' else 'WedgePart', name)
    vector(props, 'Size', size)
    cf = ET.SubElement(props, 'CoordinateFrame', {'name': 'CFrame'})
    for key, value in zip(('X', 'Y', 'Z', 'R00', 'R01', 'R02', 'R10', 'R11', 'R12', 'R20', 'R21', 'R22'), (*pos, *rotation(*rot))):
        ET.SubElement(cf, key).text = f'{value:.6f}'
    rgb = tuple(int(color.strip('#')[i:i+2], 16)/255 for i in (0, 2, 4))
    col = ET.SubElement(props, 'Color3', {'name': 'Color'})
    for channel, value in zip(('R', 'G', 'B'), rgb):
        ET.SubElement(col, channel).text = f'{value:.6f}'
    prop(props, 'bool', 'Anchored', True)
    prop(props, 'bool', 'CanCollide', collide)
    prop(props, 'bool', 'CanTouch', False)
    prop(props, 'bool', 'CanQuery', True)
    prop(props, 'bool', 'CastShadow', transparency < .5)
    prop(props, 'float', 'Transparency', transparency)
    prop(props, 'token', 'Material', material)
    prop(props, 'token', 'TopSurface', 0)
    prop(props, 'token', 'BottomSurface', 0)
    if shape != 'Wedge':
        prop(props, 'token', 'shape', {'Ball': 0, 'Block': 1, 'Cylinder': 2}[shape])
    return item


def model(parent, name):
    return node(parent, 'Model', name)[0]


def orb(parent, name, p, s, c, **kw):
    return part(parent, name, p, s, c, **kw)


def disc(parent, name, p, radius, height, color, **kw):
    return part(parent, name, p, (height, radius*2, radius*2), color, 'Cylinder', (0, 0, 90), **kw)


def beam(parent, name, a, b, radius, color, material=272):
    midpoint = tuple((x+y)/2 for x, y in zip(a, b))
    d = tuple(y-x for x, y in zip(a, b))
    length = math.sqrt(sum(x*x for x in d))
    # Cylinder axis X. Direction gives yaw and pitch.
    yaw = -math.degrees(math.atan2(d[2], d[0]))
    pitch = math.degrees(math.atan2(d[1], math.hypot(d[0], d[2])))
    return part(parent, name, midpoint, (length, radius*2, radius*2), color, 'Cylinder', (0, yaw, pitch), material)


def tree(parent, x, z, scale=1, color='39BC69', y=0):
    m = model(parent, 'WhorlleafTree')
    beam(m, 'RoundedTrunk', (x, y, z), (x+.5*scale, y+7*scale, z), .75*scale, '865539', 512)
    for k in (-1, 1):
        beam(m, 'Fork', (x, y+4*scale, z), (x+k*2.1*scale, y+8*scale, z), .35*scale, '865539', 512)
    for dx, dy, dz, radius in [(-2,7.5,0,3.5),(2,8.2,0,3.3),(0,10.1,.6,3.6),(0,8.1,-2,3.1)]:
        orb(m, 'LeafCrown', (x+dx*scale,y+dy*scale,z+dz*scale), (radius*2*scale, radius*1.6*scale, radius*2*scale), color)
    for k in range(3):
        beam(m, 'Root', (x,y+.3,z), (x+math.cos(k*2.1)*2*scale,y+.1,z+math.sin(k*2.1)*2*scale), .4*scale, '865539', 512)


def flower(parent, x, z, color='FFB7DA', scale=1, y=0):
    m = model(parent, 'StarbellFlowers')
    beam(m, 'Stem', (x,y,z), (x,y+1.2*scale,z), .11*scale, '419B5B')
    for k in range(5):
        angle = k*math.tau/5
        orb(m, 'Petal', (x+math.cos(angle)*.4*scale,y+1.2*scale,z+math.sin(angle)*.4*scale), (.7*scale,.3*scale,.7*scale), color)
    orb(m,'Pollen',(x,y+1.35*scale,z),(.35*scale,.25*scale,.35*scale),'FFE886')


def roof(parent, x, y, z, radius, color):
    # A stack of curved, scalloped eaves, a golden finial, and ribs.
    for tier in range(4):
        r = radius*(1-tier*.18)
        orb(parent,'CurvedRoofTier',(x,y+tier*1.15,z),(r*2,2.0,r*2),color)
    for k in range(8):
        a = k*math.tau/8
        orb(parent,'RoofScallop',(x+math.cos(a)*radius*.78,y-.2,z+math.sin(a)*radius*.78),(3.0,1.25,3.0),'F4C971')
    orb(parent,'GoldenFinial',(x,y+4.3,z),(1.2,2.0,1.2),'FFE49A',material=1088)


def pavilion(parent, kind, x, z, roof_color, radius=8):
    m = model(parent, kind)
    disc(m,'Foundation',(x,.5,z),radius+2,1.3,'EEE2B9',collide=True)
    disc(m,'InlaidFloor',(x,1.25,z),radius, .3,'BF93BD')
    for k in range(6):
        a = k*math.tau/6
        px,pz=x+math.cos(a)*radius*.78,z+math.sin(a)*radius*.78
        disc(m,'ColumnFoot',(px,1.8,pz),1.0,.55,'F2CF7A')
        beam(m,'IvoryColumn',(px,2,pz),(px,8,pz),.55,'FFEFD6')
        disc(m,'ColumnCapital',(px,8,pz),1.0,.55,'E6B95E')
    roof(m,x,9,z,radius+1,roof_color)
    for step in range(3):
        orb(m,'RoundedEntranceStep',(x,1.15-step*.4,z+radius+1+step*1.3),(6,.7,3),'ECDDBA',collide=True)
    return m


def bridge(parent, x, z, length=18, angle=0, wood=True):
    m=model(parent,'WillowBridge' if wood else 'MoonstoneBridge')
    def point(dx,dy,dz):
        a=math.radians(angle)
        return (x+dx*math.cos(a)+dz*math.sin(a),dy,z-dx*math.sin(a)+dz*math.cos(a))
    for k in range(int(length/1.6)):
        dz=-length/2+(k+.5)*1.6
        p=point(0,1.1+math.sin((dz/length+.5)*math.pi)*2,dz)
        part(m,'CarvedPlank',p,(7,.6,1.45),'BC8752' if wood else 'CBD9E6','Block',(0,angle,0),512 if wood else 800,collide=True)
    for side in (-1,1):
        for k in range(5):
            dz=-length/2+k*length/4
            base=1.1+math.sin((dz/length+.5)*math.pi)*2
            beam(m,'RoundRailPost',point(side*3.7,base,dz),point(side*3.7,base+2.5,dz),.23,'795139' if wood else 'CAD9EF',512 if wood else 800)
            if k:
                prev=-length/2+(k-1)*length/4
                ph=1.1+math.sin((prev/length+.5)*math.pi)*2
                beam(m,'CurvedRail',point(side*3.7,ph+2.4,prev),point(side*3.7,base+2.4,dz),.22,'D8AF70' if wood else 'E5EDF7')
    return m


def island(parent, offset=(0,0,0), showcase=False):
    xoff,yoff,zoff=offset
    m=model(parent,'IslandTemplate' if not showcase else 'ArrivalIsland')
    pivot=part(m,'IslandOrigin',(0,0,0),(1,1,1),'FFFFFF',transparency=1)
    prop(m.find('Properties'),'Ref','PrimaryPart',pivot.attrib['referent'])
    # Geometry starts local. Offset applied at the end, preserving a valid default pivot.
    terrain=model(m,'SculptedFloatingTerrain')
    disc(terrain,'NaturalGrassCanopy',(0,-.9,0),74,1.8,'62CE58',material=1280,collide=True)
    orb(terrain,'OchreTopsoil',(0,-5,0),(145,12,139),'BD985A')
    orb(terrain,'FloatingRockMass',(0,-16,0),(130,30,123),'797680',material=1312)
    orb(terrain,'TaperedUnderside',(3,-31,-2),(90,35,86),'665F78',material=1312)
    orb(terrain,'FloatingKeel',(-2,-46,5),(48,22,45),'51485F',material=1312)
    # Irregular lobes and rim boulders break the circular silhouette.
    for k in range(29):
        angle=k*math.tau/29
        rad=69+RNG.uniform(-4,5)
        x,z=math.cos(angle)*rad,math.sin(angle)*rad
        orb(terrain,'RoundedCliffStratum',(x,-7-RNG.random()*4,z),(RNG.uniform(12,21),RNG.uniform(13,24),RNG.uniform(12,20)),RNG.choice(['9B8E86','AA997D','918682','877C88']),material=1312)
        orb(terrain,'GrassOverhang',(x*.99,-.65,z*.99),(RNG.uniform(12,19),3.2,RNG.uniform(12,19)),RNG.choice(['57C957','72D963','4BBC57']),material=1280)
        if k%3==0:
            beam(terrain,'HangingTreeRoot',(x*.95,-6,z*.95),(x*.94,-19,z*.94),.65,'7A573E',512)
    for k in range(9):
        x,z=RNG.uniform(-35,35),RNG.uniform(-30,30)
        orb(terrain,'UndersideCrystal',(x,-39-RNG.random()*8,z),(2,8,2),'A6DBEA',material=288)

    landscape=model(m,'LivingLandscape')
    for x,z,s,c in [(-60,-21,1,'35AC72'),(-60,6,.8,'41BF67'),(-52,39,1.1,'2CB779'),(-28,56,.8,'36B66A'),(54,33,.8,'3DBB69'),(62,3,.9,'2FAC79'),(55,-18,1,'51BC69'),(26,-56,.95,'66BD93'),(-15,-58,.8,'43AC71'),(-46,-47,.75,'4ABB69'),(5,58,.85,'42BF8C'),(47,47,.7,'37B076')]:
        tree(landscape,x,z,s,c)
    for k in range(40):
        a=RNG.random()*math.tau
        rad=RNG.uniform(57,67)
        x,z=math.cos(a)*rad,math.sin(a)*rad
        orb(landscape,'FernBush',(x,.8,z),(RNG.uniform(2.2,4.5),RNG.uniform(1.5,2.8),RNG.uniform(2.2,4.5)),RNG.choice(['219966','33B06D','77CE60']))
        if k%2==0:
            flower(landscape,x+2,z, RNG.choice(['FFD773','FFB0D0','C9B2FF','F2F5FF']),.8)
    # Winding stepping-stone promenade stays away from placement rectangles.
    for k in range(28):
        x=-48+k*3.7
        z=39+3*math.sin(k*.32)
        orb(landscape,'PolishedPathStone',(x,.3,z),(3.3,.6,2.8),'E5DDBA',collide=True)
    for k in range(10):
        orb(landscape,'HatcheryPath',(-29+math.sin(k*.5)*2,.25,-29-k*1.4),(3.3,.5,2.4),'E5DDBA')

    water=model(m,'MoonwaterGarden')
    orb(water,'PondRockBed',(-48,.4,21),(27,1.5,23),'82BEB9')
    orb(water,'DeepTurquoisePond',(-48,1.05,21),(23,.45,19),'3DAACE',material=1568,transparency=.2)
    orb(water,'PoolGleam',(-48,1.2,21),(20,.15,16),'65E8E7',material=1568,transparency=.4)
    for k in range(12):
        a=k*math.tau/12
        orb(water,'WaterWornStone',(-48+math.cos(a)*12,.8,21+math.sin(a)*10),(3.3,2,2.6),'C8D6CC')
    for k in range(13):
        z=31+k*2.65
        x=-48+math.sin(k*.4)*4
        orb(water,'StreamBank',(x,.3,z),(8,1,5),'92CBA1')
        orb(water,'BendingStream',(x,.9,z),(5.3,.3,4.2),'75E7EA',material=1568,transparency=.2)
    bridge(water,-45,43,16,0)
    for k in range(4):
        orb(water,'WaterfallRibbon',(-47+k*1.25,-14+math.sin(k)*2,66),(1.8,32,1.15),'7CDDE9',material=1568,transparency=.26)
        orb(water,'FallingWaterFoam',(-47+k*1.25,-29,66),(2.8,1.5,2.8),'EBFFFF',transparency=.12)
    for k in range(4):
        orb(water,'LilyPad',(-54+k*3,1.5,18+k%2*4),(2,.15,2),'39A568')
        flower(water,-54+k*3,18+k%2*4,'FFCADF',.5,1.5)

    buildings=model(m,'FoundersTerrace')
    hatch=pavilion(buildings,'Hatchery',-29,-43,'438ECB',8)
    orb(hatch,'NestBowl',(-29,2.4,-43),(7,2,7),'E0B35C')
    orb(hatch,'WelcomeEgg',(-29,4,-43),(3.0,4.1,3.0),'DAF1FF')
    for k in range(5):
        orb(hatch,'EggGoldenSpot',(-29+math.sin(k*2.1)*1.1,3.3+k*.3,-44),(0.55,.5,.2),'F8CE69')
    breed=pavilion(buildings,'Breeding',3,-43,'BD69BC',7.5)
    orb(breed,'SanctuaryHeart',(3,4,-43),(2.9,2.9,1.3),'FF9DC8',material=288)
    for k in range(6):
        flower(breed,3+math.cos(k)*6,-43+math.sin(k)*6,'E4B1F4',1.0,1.4)

    farm=model(buildings,'Farmstead')
    disc(farm,'GardenBorder',(49,1,-40),11,1.4,'CCAE6C',collide=True)
    part(farm,'PloughedBed',(49,1.8,-40),(14,.5,12),'805E43','Block',material=512)
    for row in range(3):
        for col in range(4):
            x,z=43+col*3.5,-44+row*4
            orb(farm,'EmeraldCropLeaf',(x,2.7,z),(2,2.8,1.5),'6FC95B',rot=(0,col*19,20))
            orb(farm,'Sunberry',(x,2.6,z+.6),(1.1,1.2,1.1),'FFB753')
    roof(farm,49,6,-48,5,'51A273')
    beam(farm,'FarmRoofPost',(44,1,-48),(44,6,-48),.4,'D5BB85')
    beam(farm,'FarmRoofPost',(54,1,-48),(54,6,-48),.4,'D5BB85')

    arena=model(buildings,'Arena')
    disc(arena,'ArenaGoldPlinth',(29,1.4,43),13,2.8,'CFB578',collide=True)
    disc(arena,'ArenaInlay',(29,3,43),11,.4,'757CBC')
    disc(arena,'ArenaMoonRing',(29,3.3,43),8,.15,'AADDDD')
    disc(arena,'ArenaFloor',(29,3.4,43),7,.2,'7986AB')
    for k in range(8):
        a=k*math.tau/8
        px,pz=29+math.cos(a)*12,43+math.sin(a)*12
        beam(arena,'ArenaColumn',(px,2,pz),(px,7,pz),.6,'F2E1BC')
        orb(arena,'ArenaCrystal',(px,8,pz),(1.3,2.4,1.3),'ADE8EE',material=288)

    clouds=model(m,'CloudBank')
    for k in range(15):
        a=k*math.tau/15
        rad=RNG.uniform(95,125)
        x,z=math.cos(a)*rad,math.sin(a)*rad
        for j in range(3):
            orb(clouds,'CloudPuff',(x+j*7,-25-RNG.uniform(0,16),z),(RNG.uniform(18,29),RNG.uniform(9,15),RNG.uniform(13,22)),'ECFAFF',transparency=.12)
    if showcase:
        for x,c,name in [(-35,'FF9654','Emberhaven'),(5,'6CDDE9','Tidehaven'),(45,'8BCD66','Bloomhaven')]:
            h=model(m,name)
            disc(h,'GoldenHabitatRim',(x,1,5),10,1.5,'DCC088')
            disc(h,'ElementalBed',(x,1.9,5),8.7,.45,c)
            # Display-only original rounded creatures are baked for edit-mode inspection.
            d=model(h,'DevelopmentDragon')
            orb(d,'PearTorso',(x,4.5,5),(4,4.5,5),c)
            orb(d,'RoundedHead',(x,7,2.5),(3.6,3.4,3.7),c)
            orb(d,'Muzzle',(x,6.5,.8),(2.6,1.7,2),'FFEEBF')
            for side in (-1,1):
                orb(d,'Eye',(x+side*1.25,7.3,1.25),(.85,1,.4),'FFF9E3')
                orb(d,'Pupil',(x+side*1.25,7.25,1.05),(.4,.6,.23),'384263')
                orb(d,'Horn',(x+side*1.1,9,2.7),(.7,2,.7),'F9D986',rot=(0,0,side*16))
                orb(d,'Wing',(x+side*3.5,6.3,5),(4.4,.6,3),'F5D58D',rot=(0,side*15,side*25))
                orb(d,'Foot',(x+side*1.4,2.5,3.8),(1.4,1.3,2.4),c)
                orb(d,'Arm',(x+side*2,4.8,3.4),(1.1,2.2,1.1),c,rot=(0,0,side*20))
            for k in range(5):
                orb(d,'CurledTail',(x+math.sin(k*.5)*2,3.1+k*.16,7+k*1.2),(1.5-k*.2,1.5-k*.2,2.0-k*.2),c)
    if any(offset):
        for cf in m.findall('.//CoordinateFrame'):
            for axis, off in zip('XYZ',offset):
                cf.find(axis).text=f'{float(cf.find(axis).text)+off:.6f}'
    return m


def document():
    root=ET.Element('roblox',{'xmlns:xmime':'http://www.w3.org/2005/05/xmlmime','xmlns:xsi':'http://www.w3.org/2001/XMLSchema-instance','version':'4'})
    ET.SubElement(root,'External').text='null'
    ET.SubElement(root,'External').text='nil'
    return root


def save(root,path):
    ET.indent(root,space='  ')
    path.parent.mkdir(parents=True,exist_ok=True)
    ET.ElementTree(root).write(path,encoding='utf-8',xml_declaration=True)
    parts=len(root.findall('.//Item[@class="Part"]'))
    print(f'{path.relative_to(ROOT)}: {parts} anchored parts, {path.stat().st_size:,} bytes')


if __name__=='__main__':
    template=document()
    island(template)
    save(template,ROOT/'src/models/IslandTemplate.rbxmx')
    world=document()
    container=model(world,'World')
    island(container,(0,80,0),True)
    save(world,ROOT/'src/world/World.rbxmx')
