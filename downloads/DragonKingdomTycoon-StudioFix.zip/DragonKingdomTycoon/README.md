# DRAGON KINGDOM TYCOON

เกม Roblox ต้นฉบับแนวสะสมมังกรและสร้างหมู่เกาะลอยฟ้า พร้อมโครงสร้าง Rojo, ระบบ Client/Server และไฟล์ฉากสำหรับ Roblox Studio

**สถานะ: development build ที่มีระบบเกมจริง — ยังไม่ใช่ final AAA art และยังไม่ได้ทดสอบการเล่นใน Roblox Studio จากคลาวด์นี้**

## เปิดโปรเจกต์

1. เปิด `build/DragonKingdomTycoon.rbxl` หรือ `.rbxlx` ใน Roblox Studio
2. กด Play ได้โดยไม่ต้อง Publish: รุ่นพัฒนานี้เปิด `StudioMemoryMode = true` ไว้เฉพาะใน Studio และแจ้งว่าข้อมูลเป็นการทดสอบชั่วคราว ปิด Play แล้วข้อมูลจะหาย
3. เริ่มจากมังกรสามตัว ถิ่นอาศัยสามแห่ง ฟาร์ม โรงฟัก และศาลาผสมพันธุ์ที่จัดวางไว้แล้ว สำหรับการทดสอบ save จริงให้ทำตาม [วิธีตั้งค่า Studio](docs/STUDIO_SETUP.md) เซิร์ฟเวอร์ที่เผยแพร่ใช้ DataStore เสมอ

ไฟล์ build สร้างใหม่ได้จาก source; ไม่ได้เก็บใน Git เพราะ `.gitignore`:

```bash
cd /workspace/-Roblox
source /workspace/.roblox-tools/activate
python3 tools/world_generator.py
python3 tools/validate.py
```

เครื่องมือคลาวด์ที่เตรียมไว้: Luau 0.742, Rojo 7.7.1, Python 3 พร้อม msgpack ใช้ checkout เดิม ไม่ต้องสร้าง worktree

สำหรับ Linux x86_64 เครื่องใหม่ ติดตั้งเครื่องมือจาก official release ที่ตรึง SHA256 ใน `toolchain.lock.json` และ dependencies Python ก่อนตรวจเกม:

```bash
python3 tools/install_tools.py
source .tools/activate
python3 -m venv .venv
source .venv/bin/activate
python3 -m pip install -r requirements-dev.txt
python3 tools/validate.py
python3 tools/package.py
```

ใช้ Python 3.11 ขึ้นไป; installer ไม่ใช้ root และรันซ้ำได้ ไฟล์ `.tools/` และ `.venv/` ไม่เข้า Git ต้องใช้ Inkscape เพิ่มเฉพาะเมื่อสร้าง PNG จาก SVG ใหม่; assets ที่ส่งมาพร้อมใช้งานโดยไม่ต้อง regenerate บน Windows/macOS เปิด place โดยตรงได้ หรือใช้ Luau/Rojo รุ่นเดียวกันจาก official release

## สิ่งที่มีใน source

- มังกร 20 สายพันธุ์ต้นฉบับ ครบ 9 ธาตุและ 5 ความหายาก มีข้อมูลสถิติ ทักษะสามท่า การเติบโต และรูปร่าง procedural ต่างกัน
- ถิ่นอาศัย 9 แบบ การวาง/หมุน/ย้าย/นำออก ตรวจชนกัน เพิ่มระดับ ความจุมังกรและเพดานทอง; มังกรในคลังไม่ผลิตทอง
- ซื้อไข่ ฟักตาม timestamp เซิร์ฟเวอร์ รับเข้าบ้านหรือคลัง ให้อาหาร/XP/เลเวล ผสมพันธุ์แบบสุ่มบนเซิร์ฟเวอร์
- ฟาร์มสามชนิดพืช การปลูก/เก็บ/อัปเกรด การผลิตทองระหว่าง offline มีเพดาน 8 ชั่วโมง
- PvE 3v3 แบบผลัดตา ธาตุ สถิติ ลำดับความเร็ว critical cooldown AI หกด่านและรางวัลจ่ายครั้งเดียว; battle pass ใช้รางวัลจากการเล่น ไม่มีเงินจริง
- ภารกิจ ความสำเร็จ สมุดสะสม รางวัลรายวัน กิจกรรม ขยายเกาะ ซื้อ/วางของตกแต่ง และการเยี่ยมเกาะผู้เล่นในเซิร์ฟเวอร์
- HUD ริมจอ หน้าต่างใช้งานจริง กล้อง isometric แพน/หมุน/ซูม placement ghost และ input สำหรับเมาส์/สัมผัส
- การเชื่อมต่อเริ่มเกมมีเวลาหมดอายุ สถานะข้อผิดพลาด และตรวจการเชื่อมต่ออีกครั้ง; ไม่ส่งคำขอซื้อซ้ำอัตโนมัติเมื่อคำตอบยังไม่กลับมา
- DataStore `UpdateAsync` พร้อม session lease, autosave, leave/close save, schema migration, retry จำกัด และไม่เขียนข้อมูลเริ่มต้นทับเมื่อโหลดผิดพลาด

รายละเอียดความครอบคลุมและข้อจำกัดอยู่ใน [รายงาน QA](docs/QA.md) และ [รายการ assets](docs/ASSETS.md)

กิจกรรม Aurora Celebration เปิด 11 ต.ค. 2026 เวลา 00:00 ถึงก่อน 1 พ.ย. 2026 เวลา 00:00 ตามเวลาประเทศไทย เกณฑ์คือทองที่เก็บสะสมทั้งหมด 500 หน่วย และรับได้ครั้งเดียวภายในช่วงกิจกรรม ส่วน Sky Bloom เป็นกิจกรรมถาวร เวลาและรางวัลทั้งหมดอยู่ใน `Config.Balance`

## วงจรเริ่มต้น

1. เลือกมังกรเพื่อดูค่าสถานะและให้อาหาร
2. แตะ Habitat เพื่อเก็บทอง เปิด Farm เพื่อปลูก Sun Berries แล้วรับอาหารเมื่อครบเวลา
3. เปิด Storage/Hatchery เริ่มฟักไข่เริ่มต้น เมื่อครบเวลารับเข้าถิ่นอาศัยธาตุตรงกัน; บ้านเต็มจะส่งเข้าคลัง
4. เปิด Build เพื่อซื้อและเลือกจุดวางบ้าน ใช้ R หรือปุ่มหมุน 90° แล้วกดยืนยัน
5. เปิด Breeding เลือกพ่อแม่เลเวลถึงเกณฑ์สองตัว รับไข่หลังครบเวลา
6. เลือกทีมสามตัวใน Battle แล้วเลือกทักษะ/เป้าหมายตามลำดับตา
7. รับรางวัล Quest/Daily/Collection แล้วปลดล็อกเกาะเพิ่มเติม

## โครงสร้าง

```text
src/shared/Config/       มังกร ถิ่นอาศัย economy และ asset bindings
src/shared/Engine.luau   ธุรกรรมและกฎเกมที่ทดสอบด้วย Luau ได้
src/shared/Domain/       ระบบต่อสู้
src/shared/DragonArt     โมเดลมังกร procedural ต้นฉบับ
src/server/Data/         DataStore และ session lease
src/server/Services/     services, remote validation, world rendering
src/client/Controllers/  UI, camera, input, animation
src/models/              template เกาะจริงแบบ .rbxmx
src/world/               ฉากเริ่มต้นจริงแบบ .rbxmx
art/                     artwork ต้นฉบับและไฟล์สำหรับนำเข้า
tools/                   generation, asset import, build/validation
tests/                   domain, security และ persistence tests
docs/                    installation, contract, assets และ QA
```

## ขอบเขตการยืนยัน

ทดสอบกฎเกมและ build ได้บน Linux; Roblox Studio มีเฉพาะ Windows/macOS จึงต้องตรวจภาพ UI, ท่าทางสัมผัส, FPS, multiplayer และการบันทึกกับ DataStore จริงตาม checklist เพิ่มเติม ไฟล์ artwork ที่ส่งมาเป็นต้นฉบับ แต่ต้องอัปโหลดและผูก Roblox asset IDs ก่อนแสดงเป็น ImageLabel/Sound จริง โมเดลมังกร procedural ใช้เพื่อ development; รายการ custom meshes/rigged animation ที่ยังขาดเปิดเผยใน manifest ภาพใน `art/concepts/` เป็น concept art ไม่ใช่ screenshot จากเกม

ห้ามนำ test build นี้ไปอ้างว่าเป็นงานศิลป์ final หรือว่าผ่าน Studio acceptance ทั้งหมดแล้ว
