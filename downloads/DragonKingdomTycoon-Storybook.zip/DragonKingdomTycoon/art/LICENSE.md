# Original project assets

The vector source icons, PNG renders, synthesized WAV files and generated illustrations in this directory were created specifically for Dragon Kingdom Tycoon. They contain no borrowed game logos, named game characters, audio samples or third-party asset packs.

The original vector drawings and synthesized audio are project-authored assets. The two illustrated PNGs were generated using OpenAI's image generation tool from original fantasy-art prompts. Use, adapt and upload these outputs for this project under the applicable generation service terms and your project's publication rights. This provenance statement does not claim exclusive copyright in an AI-generated image.

Source icon geometry lives in `tools/assets_build.py` and `art/source/icons`. The soundtrack and effects use mathematical synthesis from `tools/assets_audio.py`, with no external recordings. `art/manifest.json` records their hashes and local paths.

The floating-kingdom image is concept art, not a screenshot of the running game. The portrait atlas is original illustration awaiting consistency review against final dragon meshes. Vector icons and audio are development assets that require in-game art direction and listening review. No final AAA quality is claimed.
