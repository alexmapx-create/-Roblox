# Original illustration recipes

Both illustrations were generated using OpenAI's image generation tool for this project. The image tool's original saved files were copied without editing into the repository. The reference game's assets were not provided as source images to the generation call. These recipes support future art direction; image generation is not pixel-deterministic.

## Floating kingdom concept

Original premium fantasy mobile-game cover illustration with no lettering, logos, brands, text, watermark or interface. An adorable but powerful emerald dragon with amber eyes, leaf antlers, amber membraned wings, four curved paws and a curling leaf-fin tail stands on a natural floating grassy island over soft clouds. Original bronze-roof nursery towers, crystalline pond, waterfall, jewel flowers and foliage; original finned water dragon and fiery lion dragon on side islands. Isometric three-quarter view, stylized painted cartoon 3D fantasy, jewel colors, luminous rim light, distinct original designs. Concept only; not a runtime screenshot.

## Dragon portrait sprite atlas

Exactly 20 original fantasy cartoon dragon busts, clean transparent background, equally sized tiles, 5 columns × 4 rows, no text/labels/logo/UI/frame; each portrait stays in its tile. Expressive eyes, horns, snout, chest and partial wing, jewel-colored hand-painted 3D styling. Row 1: fire-lion mane, turquoise gill-finned water, emerald leafy nature, sandstone rock-armored earth, electric golden lightning-horn dragon. Row 2: blue crystal ice, violet bat-frilled shadow, pearl feather-wing light, charcoal volcanic, royal-blue coral water. Row 3: pink floral forest, copper mineral mountain, indigo storm, lilac feathered snow, magenta crescent-horn moon. Row 4: golden radiating sun, rainbow opal, azure star-pattern cosmic, emerald-bronze ancient guardian, ivory aurora antlers. No existing game characters or copied designs.

The tile-to-species mappings are explicit in `tools/assets_catalog.py`. This illustrated concept series still requires color/silhouette consistency review against final meshes; it does not establish that final custom 3D characters exist.
