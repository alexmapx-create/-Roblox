# เปิดและทดสอบใน Roblox Studio

## เปิดไฟล์ที่สร้างไว้

เปิด `build/DragonKingdomTycoon.rbxl` หรือ `.rbxlx` ผ่าน File → Open from File บน Windows/macOS โครงสร้าง source และฉาก baked จะอยู่ในไฟล์เดียว ไม่ต้องหาโมเดลจาก Toolbox

ถ้าต้องการแก้ source ผ่าน Rojo ให้ติดตั้ง CLI/Studio plugin รุ่น 7.7.1 จาก [Rojo ทางการ](https://github.com/rojo-rbx/rojo/releases/tag/v7.7.1) แล้วรัน:

```bash
rojo serve default.project.json --address 127.0.0.1 --port 34872
```

เชื่อม plugin กับพอร์ตนี้บนเครื่องเดียวกัน ไม่ต้องเผยแพร่ localhost เป็น web preview

## กด Play ครั้งแรก

รุ่นพัฒนาที่แก้ปัญหาหน้าค้างโหลดเปิด `StudioMemoryMode = true` ไว้แล้วใน `ServerScriptService.GameServer.RuntimeConfig` กด Play ใน Studio ได้โดยไม่ต้อง Publish หรือเปิด API Services ข้อมูลเป็นการทดสอบชั่วคราว และจะแจ้งว่าไม่บันทึกไว้บน HUD ปิด Play แล้วข้อมูลจะหาย

**ทดสอบแบบบันทึกจริง:** Stop ก่อน เปลี่ยน `StudioMemoryMode = false` แล้ว Save/Publish ไปยัง place ทดสอบที่คุณเป็นเจ้าของ เปิด Game Settings → Security → Enable Studio Access to API Services และใช้ `RuntimeConfig.DataStoreName` สำหรับข้อมูลทดสอบโดยเฉพาะ เช่น `DragonKingdomProfiles_Test_v1` จากนั้น Play และทดสอบ save/leave/rejoin ใน place เดิม

โหมด memory มีผลเฉพาะเมื่อ `RunService:IsStudio()` เป็นจริง เซิร์ฟเวอร์ที่เผยแพร่ใช้ DataStore เสมอแม้ flag นี้เป็น true หากเข้าถึง DataStore ไม่ได้ การโหลดจะแจ้งข้อผิดพลาดและไม่สร้าง save เริ่มต้นทับข้อมูลเดิม

เมื่อแก้ source ให้เปลี่ยน `src/server/RuntimeConfig.luau` แล้ว build ใหม่ หรือ sync ผ่าน Rojo อย่าสลับ DataStore ของเกมจริงเข้ามาทดสอบโดยไม่ได้ตั้งใจ

## หากยังเห็นแต่ท้องฟ้าหรือข้อความเชื่อมต่อ

1. ตรวจว่าเปิดไฟล์ `.rbxl` รุ่นแก้ไข ไม่ใช่ไฟล์เก่าที่ดาวน์โหลดไว้ก่อนหน้า
2. ถ้าใช้ไฟล์เก่า ให้ Stop → Explorer → ServerScriptService → GameServer → RuntimeConfig แล้วเปลี่ยน `StudioMemoryMode = true` ก่อน Play ใหม่
3. หน้าต่างเชื่อมต่อรุ่นใหม่แสดงรหัสและขั้นตอนที่ติดขัด ปุ่มตรวจการเชื่อมต่ออีกครั้งจะตรวจสถานะเซิร์ฟเวอร์ ไม่รีเซ็ต save หรือส่งการซื้อซ้ำ
4. `DATASTORE_UNAVAILABLE`: หากตั้งใจใช้การบันทึกจริง ให้ตรวจ Publish/API Services และชื่อ DataStore; ถ้าต้องการลองเกมชั่วคราว ให้ Stop แล้วเปิด flag memory ก่อน Play ใหม่
5. `WORLD_UNAVAILABLE`: ตรวจว่าไฟล์มี ServerStorage.IslandTemplate และใช้ project/build เต็มชุด เปิด Window (หน้าต่าง) → Output เพื่อดูสาเหตุจากเซิร์ฟเวอร์; Studio รุ่นเก่าใช้ View → Output
6. เมื่อเซิร์ฟเวอร์ไม่ตอบ หรือ client เริ่มภาพไม่ได้ ให้ดูข้อความ `[Startup]`/connection ใน Output และบันทึกรหัสข้อผิดพลาด หน้าจอจะไม่รอโดยไม่มีข้อความตลอดไป

## การควบคุม

- คลิก/แตะมังกร อาคาร หรือ Habitat เพื่อเปิดข้อมูล
- ลากพื้นที่ว่างเพื่อแพน ใช้ scroll/pinch เพื่อซูม; ควบคุมการหมุนตาม Camera module และปุ่ม reset ใน HUD
- Build mode: เลือกจุดวาง ghost สีเขียว หมุนด้วย R/ปุ่มหมุน กดจุดวางหรือปุ่มยืนยัน Escape/Cancel ยกเลิก
- การกด GUI ไม่ควรเลือกวัตถุในแมพ ต้องตรวจทั้ง mouse และ touch ใน Studio Device Emulator

## Artwork และเสียง

อ่าน `docs/ASSETS.md` และ manifest ใน `art/` อัปโหลดไฟล์ต้นฉบับผ่าน Creator Dashboard ในบัญชี/กลุ่มเจ้าของ experience และให้สิทธิ์ audio ที่เหมาะสม จากนั้นใช้เครื่องมือ binding ที่ให้มาเพื่อสร้าง `Config.Assets` ด้วย ID ที่อัปโหลดจริง ไม่มีการใส่ ID ปลอมหรือคัดลอก asset จากเกมอ้างอิง

จนกว่าจะผูก ID เกมใช้ ViewportFrame/โมเดล procedural และ gradient UI สำหรับ development ข้อจำกัดนี้เป็นงานศิลป์ที่ยังไม่ผ่าน final acceptance

## ทดสอบหลายผู้เล่นและการบันทึก

1. ใช้ Test → Start Server กับผู้เล่นสองคน
2. ตรวจว่าแต่ละคนมีเกาะ/ทรัพยากรแยกกัน เยี่ยมเกาะเพื่อนแล้วแก้ข้อมูลไม่ได้
3. ซื้อไข่/ฟัก/ให้อาหาร เก็บทอง ปลูกอาหาร ผสมพันธุ์และจบการต่อสู้
4. ออกจากเซิร์ฟเวอร์แล้วเข้า place ทดสอบเดิม ตรวจจำนวนไข่ มังกร ตำแหน่ง Habitat และยอดเงิน
5. ทดสอบปิดเซิร์ฟเวอร์จาก Studio และดู Output; ห้ามยืนยัน persistence จากโหมด memory
6. ถ้า session ก่อนหน้ายังไม่ release ให้รอ lease/retry ตามข้อความ ไม่ลบ DataStore เพื่อแก้ปัญหา

Checklist รายระบบและผลคลาวด์จริงอยู่ใน `docs/QA.md` ห้ามถือว่าไฟล์ build สำเร็จหมายถึงการทดสอบ Studio ผ่านแล้ว
