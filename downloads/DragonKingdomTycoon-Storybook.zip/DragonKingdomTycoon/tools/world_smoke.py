#!/usr/bin/env python3
"""Headless geometry/reconciliation checks; does not replace Roblox Studio rendering QA.

Runs real DragonArt/WorldBuilder code against a minimal geometry-only Roblox test double.
Requires the cloud Luau CLI, or LUAU_BIN pointing to a compatible Luau binary.
"""
from pathlib import Path
import os
import shutil
import subprocess
import tempfile
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
MOCK=r'''
local V={};V.__index=function(t,k)
 if k=="Magnitude" then return math.sqrt(t.X*t.X+t.Y*t.Y+t.Z*t.Z) end
 if k=="Unit" then local n=t.Magnitude;return setmetatable({X=t.X/n,Y=t.Y/n,Z=t.Z/n},V) end
 return V[k]
end
local Vector3={}
function Vector3.new(x,y,z)return setmetatable({X=x or 0,Y=y or 0,Z=z or 0,_type="Vector3"},V)end
Vector3.zero=Vector3.new();Vector3.one=Vector3.new(1,1,1);Vector3.yAxis=Vector3.new(0,1,0)
V.__add=function(a,b)return Vector3.new(a.X+b.X,a.Y+b.Y,a.Z+b.Z)end
V.__sub=function(a,b)return Vector3.new(a.X-b.X,a.Y-b.Y,a.Z-b.Z)end
V.__mul=function(a,b)if type(a)=="number" then a,b=b,a end;return Vector3.new(a.X*b,a.Y*b,a.Z*b)end
V.__div=function(a,b)return a*(1/b)end
V.__eq=function(a,b)return math.abs(a.X-b.X)<1e-7 and math.abs(a.Y-b.Y)<1e-7 and math.abs(a.Z-b.Z)<1e-7 end
local C={}
local CFrame={}
local function make(p,r)return setmetatable({Position=p,_r=r or {1,0,0,0,1,0,0,0,1},_type="CFrame"},C)end
function CFrame.new(x,y,z)if type(x)=="table" then return make(x) end;return make(Vector3.new(x,y,z))end
local function apply(r,p)return Vector3.new(r[1]*p.X+r[2]*p.Y+r[3]*p.Z,r[4]*p.X+r[5]*p.Y+r[6]*p.Z,r[7]*p.X+r[8]*p.Y+r[9]*p.Z)end
function CFrame.Angles(x,y,z)
 local cx,sx,cy,sy,cz,sz=math.cos(x),math.sin(x),math.cos(y),math.sin(y),math.cos(z),math.sin(z)
 return make(Vector3.zero,{cy*cz,-cy*sz,sy,cx*sz+sx*sy*cz,cx*cz-sx*sy*sz,-sx*cy,sx*sz-cx*sy*cz,sx*cz+cx*sy*sz,cx*cy})
end
CFrame.identity=CFrame.new()
C.__mul=function(a,b)
 if b._type=="Vector3" then return a.Position+apply(a._r,b) end
 local r={};for row=0,2 do for col=0,2 do local n=0;for k=0,2 do n+=a._r[row*3+k+1]*b._r[k*3+col+1] end;r[row*3+col+1]=n end end
 return make(a.Position+apply(a._r,b.Position),r)
end
C.__eq=function(a,b)if a.Position~=b.Position then return false end;for i=1,9 do if math.abs(a._r[i]-b._r[i])>1e-7 then return false end end;return true end
C.__index=function(a,k)if k=="Rotation" then return make(Vector3.zero,a._r) end;return C[k]end
function C:Inverse()local r=self._r;local t={r[1],r[4],r[7],r[2],r[5],r[8],r[3],r[6],r[9]};return make(apply(t,self.Position*-1),t)end
function CFrame.lookAt(a,b)
 local d=(b-a).Unit
 return CFrame.new(a)*CFrame.Angles(0,math.atan2(-d.X,-d.Z),0)
end
local function typeof(v)return type(v)=="table" and v._type or type(v)end
local Color3={}
function Color3.new(r,g,b)return {R=r,G=g,B=b}end
function Color3.fromRGB(r,g,b)return Color3.new(r/255,g/255,b/255)end
function Color3.fromHex(s)s=s:gsub("#","");return Color3.fromRGB(tonumber(s:sub(1,2),16),tonumber(s:sub(3,4),16),tonumber(s:sub(5,6),16))end
local function creator(...)return {...}end
local NumberSequence={new=creator};local NumberSequenceKeypoint={new=creator};local NumberRange={new=creator};local ColorSequence={new=creator}
local Vector2={new=function(x,y)return {X=x,Y=y}end};local UDim={new=creator};local UDim2={fromOffset=creator,fromScale=creator}
local Enum=setmetatable({},{__index=function(t,k)local group=setmetatable({},{__index=function(g,n)rawset(g,n,n);return n end});rawset(t,k,group);return group end})
local function event()
 local e={listeners={}}
 function e:Connect(fn)local connection={active=true};function connection:Disconnect()self.active=false end;table.insert(self.listeners,{fn=fn,connection=connection});return connection end
 function e:Fire(...)for _,listener in self.listeners do if listener.connection.active then listener.fn(...)end end end
 return e
end
local Methods={}
local M={}
M.__index=function(t,k)
 if k=="Parent" then return rawget(t,"_parent") end
 if k=="Position" and rawget(t,"CFrame") then return t.CFrame.Position end
 if Methods[k] then return Methods[k] end
 for _,c in t._children do if c.Name==k then return c end end
end
M.__newindex=function(t,k,v)
 if k=="Parent" then
  local old=rawget(t,"_parent");if old then for i,c in old._children do if c==t then table.remove(old._children,i);break end end end
  rawset(t,"_parent",v);if v then table.insert(v._children,t) end
 else rawset(t,k,v) end
end
local Instance={}
function Instance.new(class)
 local t=setmetatable({_children={},_attributes={},_attributeSignals={},ClassName=class,Name=class},M)
 if class=="Part" or class=="WedgePart" then t.CFrame=CFrame.identity;t.Size=Vector3.one;t.Transparency=0 end
 if class=="Motor6D" then t.C0=CFrame.identity;t.C1=CFrame.identity end
 return t
end
function Methods:IsA(class)return self.ClassName==class or class=="BasePart" and (self.ClassName=="Part" or self.ClassName=="WedgePart") end
function Methods:GetChildren()return table.clone(self._children)end
function Methods:GetDescendants()local out={};local function walk(n)for _,c in n._children do table.insert(out,c);walk(c)end end;walk(self);return out end
function Methods:FindFirstChild(name,recursive)
 for _,c in self._children do if c.Name==name then return c end end
 if recursive then for _,c in self._children do local found=c:FindFirstChild(name,true);if found then return found end end end
end
function Methods:WaitForChild(name)return assert(self:FindFirstChild(name),"Missing mock child:"..name)end
function Methods:SetAttribute(k,v)local changed=self._attributes[k]~=v;self._attributes[k]=v;if changed and self._attributeSignals[k]then self._attributeSignals[k]:Fire()end end
function Methods:GetAttribute(k)return self._attributes[k]end
function Methods:GetAttributeChangedSignal(k)self._attributeSignals[k]=self._attributeSignals[k]or event();return self._attributeSignals[k]end
function Methods:GetPivot()return self.PrimaryPart and self.PrimaryPart.CFrame or self._pivot or CFrame.identity end
function Methods:PivotTo(target)
 local delta=target*self:GetPivot():Inverse()
 for _,p in self:GetDescendants()do if p:IsA("BasePart") then p.CFrame=delta*p.CFrame end end
 self._pivot=target
end
function Methods:ScaleTo(scale)
 local factor=scale/(self._scale or 1);local pivot=self:GetPivot()
 for _,p in self:GetDescendants()do
  if p:IsA("BasePart") then p.Size=p.Size*factor;p.CFrame=make(pivot.Position+(p.CFrame.Position-pivot.Position)*factor,p.CFrame._r)
  elseif p:IsA("Motor6D")then p.C0=make(p.C0.Position*factor,p.C0._r)end
 end;self._scale=scale
end
function Methods:AddPersistentPlayer(p)self.PersistentPlayer=p end
function Methods:Destroy()for _,c in self:GetChildren()do c:Destroy()end;self.Parent=nil;self._destroyed=true end
function Methods:Clone()
 local refs={}
 local function copy(n)local r=Instance.new(n.ClassName);refs[n]=r;for k,v in n do if k~="_children" and k~="_parent" and k~="_attributes" and k~="_attributeSignals" then rawset(r,k,v)end end;r._attributes=table.clone(n._attributes);for _,c in n._children do local clone=copy(c);clone.Parent=r end;return r end
 local result=copy(self)
 for source,target in refs do if source.PrimaryPart then target.PrimaryPart=refs[source.PrimaryPart]end end
 return result
end
local workspace=Instance.new("Folder");workspace.Name="Workspace"
workspace.DescendantAdded=event();workspace.DescendantRemoving=event()
local replicated=Instance.new("Folder");local storage=Instance.new("Folder")
local shared=Instance.new("Folder");shared.Name="Shared";shared.Parent=replicated
local tags={}
local collection={AddTag=function(_,m,tag)tags[m]=tag end}
local game={GetService=function(_,name)return ({ReplicatedStorage=replicated,ServerStorage=storage,CollectionService=collection})[name]end}
local template=Instance.new("Model");template.Name="IslandTemplate";template.Parent=storage
local pivot=Instance.new("Part");pivot.Name="IslandOrigin";pivot.Parent=template;template.PrimaryPart=pivot
for _,name in {"Hatchery","Breeding","Arena","Farmstead"}do local building=Instance.new("Model");building.Name=name;building.Parent=template end
local player={UserId=101,Name="SmokeTester"}
'''

CHECKS=r'''
local distinct={}
local minParts,maxParts=99999,0
for _,spec in DragonsConfig.List do
 local visual=DragonArt.build(spec,4)
 assert(visual.PrimaryPart and visual:GetAttribute("Shape")==spec.shape)
 assert(visual:GetAttribute("ArtStatus")=="procedural_development_pending_custom_mesh")
 local counts={};local parts,joints=0,0
 for _,object in visual:GetDescendants()do
  if object:IsA("BasePart")then parts+=1;assert(object.Anchored and not object.CanCollide,"Unsafe dragon physics");counts[object.Name]=(counts[object.Name]or 0)+1
  elseif object:IsA("Motor6D")then joints+=1;assert(object.Part0 and object.Part1)end
 end
 assert(parts>50 and joints==parts-1,"Missing anatomical joints: "..spec.id.." parts="..parts.." joints="..joints)
 local signature="";local names={};for name in counts do table.insert(names,name)end;table.sort(names)
 for _,name in names do signature..=name..counts[name]end
 assert(not distinct[signature],"Palette-only duplicated silhouette: "..spec.id);distinct[signature]=true
 assert(counts.ExpressiveHead and counts.IvoryEye==2 and counts.MoonHorn==2 and counts.LittleArm==2 and counts.SoftPaw==2 and counts.TailSegment1)
 minParts=math.min(minParts,parts);maxParts=math.max(maxParts,parts)
 local baby=DragonArt.build(spec,1);local adult=DragonArt.build(spec,12)
 assert(baby:GetAttribute("GrowthStage")=="Baby" and adult:GetAttribute("GrowthStage")=="Adult")
 assert(baby.PearTorso.Size.Y<visual.PearTorso.Size.Y and visual.PearTorso.Size.Y<adult.PearTorso.Size.Y)
end
print("PASS:20 original anatomical signatures,3growthstages,anchored Motor6D trees;part range",minParts,maxParts)
local profile={habitats={},dragons={},farms={farm1={id="farm1",level=1}},hatches={},islands={main=true},decorations={},buildingLevels={}}
for i,element in {"fire","water","nature","earth","electric","ice","dark","light","legendary"}do
 local id="h"..i;profile.habitats[id]={id=id,element=element,level=1,x=i-5,z=0,rotation=0,storedGold=12}
end
profile.dragons.d1={id="d1",species="cinder_mane",level=4,hunger=80,habitatId="h1"}
profile.hatches.a={id="a",species="coral_fin",readyAt=os.time()+20}
profile.hatches.b={id="b",species="moss_antler",readyAt=os.time()+40}
local island=WorldBuilder.createIsland(player,Vector3.new(500,80,0))
assert(WorldBuilder.getIsland(player)==island and island.PrimaryPart.CFrame.Position==Vector3.new(500,80,0))
WorldBuilder.syncIsland(player,profile)
local dragon=island.ProfileVisuals:FindFirstChild("Dragon_d1")
local habitat=island.ProfileVisuals:FindFirstChild("Habitat_h1")
local eggB=island.ProfileVisuals:FindFirstChild("Egg_b")
local firstEggB=eggB:GetPivot().Position
local initialCount=#island:GetDescendants()
WorldBuilder.syncIsland(player,profile)
assert(island.ProfileVisuals:FindFirstChild("Dragon_d1")==dragon and island.ProfileVisuals:FindFirstChild("Habitat_h1")==habitat and #island:GetDescendants()==initialCount,"Repeated sync recreated stable visuals")
WorldView.init({})
local homeSnapshot={userId=player.UserId,profile=profile,origin={x=500,y=80,z=0}}
WorldView.refresh(homeSnapshot)
assert(habitat.CollectReady.MaxDistance==0 and habitat.CollectReady.Enabled,"Overview hid owner's ready marker")
profile.habitats.h1.storedGold=0;WorldBuilder.syncIsland(player,profile)
assert(not habitat.CollectReady.Enabled,"Empty habitat kept collect marker")
profile.habitats.h1.storedGold=12;WorldBuilder.syncIsland(player,profile)
assert(habitat.CollectReady.Enabled,"Readiness update failed to enable owned marker")
local neighbor={UserId=202,Name="Neighbor"}
local neighborIsland=WorldBuilder.createIsland(neighbor,Vector3.new(760,80,0));WorldBuilder.syncIsland(neighbor,profile)
local neighborMarker=neighborIsland.ProfileVisuals.Habitat_h1.CollectReady
for _,object in neighborIsland:GetDescendants()do workspace.DescendantAdded:Fire(object)end
assert(not neighborMarker.Enabled,"Newly streamed neighbor marker leaked into own view")
local unrelated=Instance.new("BillboardGui");unrelated.Enabled=true;unrelated.Parent=workspace;workspace.DescendantAdded:Fire(unrelated)
unrelated:SetAttribute("OwnerUserId",neighbor.UserId);unrelated:SetAttribute("MarkerReady",true)
WorldView.refresh({userId=neighbor.UserId,visiting=neighbor.UserId,profile=profile,origin={x=760,y=80,z=0}})
assert(neighborMarker.Enabled and not habitat.CollectReady.Enabled,"Visit did not scope markers to viewed owner")
WorldView.refresh(homeSnapshot)
assert(habitat.CollectReady.Enabled and not neighborMarker.Enabled,"ReturnHome failed to restore marker scope")
assert(unrelated.Enabled,"Kingdom scope modified an unrelated billboard")
local streamed=Instance.new("BillboardGui");streamed.Enabled=false;streamed.Parent=workspace;workspace.DescendantAdded:Fire(streamed)
streamed:SetAttribute("OwnerUserId",player.UserId);streamed:SetAttribute("MarkerReady",true);streamed:SetAttribute("KingdomMarker",true)
assert(streamed.Enabled,"Late streamed marker attributes were missed")
streamed:SetAttribute("OwnerUserId",neighbor.UserId);assert(not streamed.Enabled,"Owner attribute change left foreign marker visible")
workspace.DescendantRemoving:Fire(streamed);streamed:SetAttribute("OwnerUserId",player.UserId)
assert(not streamed.Enabled,"Streamed-out marker retained attribute callbacks")
streamed:Destroy();workspace.DescendantRemoving:Fire(unrelated);unrelated:Destroy()
WorldBuilder.removeIsland(neighbor)
print("PASS:overview markers preserve readiness and scope home/visit/return/new streaming to viewed owner")
profile.hatches.a=nil;profile.hatches.c={id="c",species="ember_wing",readyAt=os.time()+30}
WorldBuilder.syncIsland(player,profile)
assert(island.ProfileVisuals:FindFirstChild("Egg_b")==eggB and eggB:GetPivot().Position~=firstEggB)
assert(eggB:GetPivot().Position~=island.ProfileVisuals.Egg_c:GetPivot().Position,"Hatch slot overlap")
profile.decorations={{id="decor1",kind="lantern",x=5,z=15,rotation=90}}
profile.islands.frost=true;profile.islands.storm=true;profile.islands.sanctum=true
WorldBuilder.syncIsland(player,profile)
assert(island.ProfileVisuals.Decoration_decor1:GetPivot().Position==Vector3.new(505,80,15),"Decoration stud/grid mismatch")
for _,id in {"frost","storm","sanctum"}do assert(island.ProfileVisuals:FindFirstChild("Expansion_"..id))end
local profileDragon=profile.dragons.d1
profileDragon.level=5;WorldBuilder.syncIsland(player,profile);assert(island.ProfileVisuals.Dragon_d1==dragon,"Level within growthstage recreated model")
profileDragon.level=12;WorldBuilder.syncIsland(player,profile);assert(island.ProfileVisuals.Dragon_d1~=dragon and island.ProfileVisuals.Dragon_d1:GetAttribute("GrowthStage")=="Adult")
profileDragon.habitatId=nil;WorldBuilder.syncIsland(player,profile);assert(not island.ProfileVisuals:FindFirstChild("Dragon_d1"),"Storage dragon still in world")
profile.battle={startedAt=os.time(),stage=1,turnCount=1,round=1,status="active",allies={},enemies={},recentEvents={{side="allies",index=1,targetSide="enemies",target=1}}}
for i=1,3 do profile.battle.allies[i]={species="cinder_mane",level=4,hp=100,maxHp=100};profile.battle.enemies[i]={species="coral_fin",level=4,hp=90,maxHp=100}end
WorldBuilder.syncIsland(player,profile)
local battle=island.ProfileVisuals.BattleVisuals
local actor=battle.Battle_allies_1
assert(actor:GetAttribute("ObjectType")=="BattleDragon" and actor:GetAttribute("AnimationQueue")=="Attack:0")
assert(battle.Battle_enemies_1:GetAttribute("AnimationQueue")=="Hurt:0.2")
WorldBuilder.syncIsland(player,profile);assert(island.ProfileVisuals.BattleVisuals==battle and battle.Battle_allies_1==actor)
profile.battle.status="won";WorldBuilder.syncIsland(player,profile);assert(actor:GetAttribute("AnimationState")=="Victory")
profile.stats={battlesStarted=2};profile.battle.status="active";profile.battle.allies[1].species="moss_antler"
WorldBuilder.syncIsland(player,profile)
assert(island.ProfileVisuals.BattleVisuals~=battle and island.ProfileVisuals.BattleVisuals.Battle_allies_1:GetAttribute("SpeciesId")=="moss_antler","Same-second battle reused previous team")
WorldBuilder.removeIsland(player);assert(not WorldBuilder.getIsland(player) and island._destroyed)
print("PASS:9habitat biomes,idempotent sync,growth changes,storage,hatch slot reuse,stud decorations,3expansions,3v3battle actionqueues,remove lifecycle")
'''

def main():
    for relative in ('src/models/IslandTemplate.rbxmx','src/world/World.rbxmx'):
        xml=ET.parse(ROOT/relative)
        parts=xml.findall('.//Item[@class="Part"]')
        assert len(parts)>700
        assert all(p.find('./Properties/bool[@name="Anchored"]').text=='true' for p in parts)
        assert xml.find('.//Item[@class="Model"]/Properties/Ref[@name="PrimaryPart"]') is not None
        names={p.find('./Properties/string[@name="Name"]').text for p in parts}
        assert {'RoundedCliffStratum','LeafCrown','Petal','WaterfallRibbon','CarvedPlank','CurvedRoofTier','IvoryColumn','CloudPuff'}<=names
        print(f'PASS:{relative}: {len(parts)} anchored parts with detailed baked landscape')
    dragons=(ROOT/'src/shared/Config/Dragons.luau').read_text()
    art=(ROOT/'src/shared/DragonArt.luau').read_text()
    world=(ROOT/'src/server/Services/WorldBuilder.luau').read_text()
    world=world.replace('require(Shared.Config.Dragons)','DragonsConfig').replace('require(Shared.Config.Habitats)','{}').replace('require(Shared.DragonArt)','DragonArt')
    view=(ROOT/'src/client/Controllers/WorldView.luau').read_text().replace('require(script.Parent.Camera)','{}').replace('require(script.Parent.Animation)','{}')
    script=MOCK+'\nlocal DragonsConfig=(function()\n'+dragons+'\nend)()\nlocal DragonArt=(function()\n'+art+'\nend)()\nlocal WorldBuilder=(function()\n'+world+'\nend)()\nlocal WorldView=(function()\n'+view+'\nend)()\n'+CHECKS
    binary=os.environ.get('LUAU_BIN') or shutil.which('luau') or '/workspace/.roblox-tools/bin/luau'
    with tempfile.TemporaryDirectory(prefix='dragon-world-smoke-') as directory:
        target=Path(directory)/'world_smoke.luau'
        target.write_text(script)
        subprocess.run([binary,str(target)],check=True,cwd=ROOT)

if __name__=='__main__':main()
