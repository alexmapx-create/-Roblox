#!/usr/bin/env python3
"""Package reviewed project sources, original assets and the current checked place."""
from pathlib import Path
import hashlib
import json
import os
import zipfile

ROOT = Path(__file__).resolve().parents[1]
BUILD = ROOT / 'build'
PREFIX = 'DragonKingdomTycoon/'
ARCHIVE = BUILD / 'DragonKingdomTycoon-source.zip'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    report = json.loads((BUILD / 'validation.json').read_text())
    assert report['status'] == 'passed_cloud_checks_studio_unrun', 'Run validation successfully before packaging.'
    files = [ROOT / name for name in ('.gitignore', '.luaurc', 'README.md', 'default.project.json',
             'requirements-dev.txt', 'toolchain.lock.json')]
    for folder in ('src', 'tests', 'tools', 'docs', 'art'):
        files.extend(p for p in (ROOT / folder).rglob('*') if p.is_file()
                     and '__pycache__' not in p.parts and p.suffix != '.pyc')
    files.extend(BUILD / name for name in ('DragonKingdomTycoon.rbxl', 'DragonKingdomTycoon.rbxlx',
                                         'sourcemap.json', 'validation.json'))
    preview = BUILD / 'preview' / 'DragonKingdomTycoon-Storybook.png'
    preview_metadata = preview.with_suffix('.metadata.json')
    if preview.exists() or preview_metadata.exists():
        assert preview.exists() and preview_metadata.exists(), 'Incomplete offline preview pair.'
        provenance = json.loads(preview_metadata.read_text())
        assert provenance.get('sourceHashes'), 'Offline preview is missing source provenance.'
        for name, expected in provenance['sourceHashes'].items():
            source = ROOT / name
            assert source.resolve().is_relative_to(ROOT.resolve()), f'Invalid preview source path: {name}'
            assert sha(source.read_bytes()) == expected, f'Rerender changed preview source: {name}'
        assert sha(preview.read_bytes()) == provenance['previewSha256'], 'Offline preview PNG hash mismatch.'
        files.extend((preview, preview_metadata))
    files = sorted(set(files))
    for name, metadata in report['artifacts'].items():
        content = (BUILD / name).read_bytes()
        assert len(content) == metadata['bytes'] and sha(content) == metadata['sha256'], f'Stale artifact: {name}'
    for path in (ROOT / 'src').rglob('*.luau'):
        assert path.stat().st_mtime <= (BUILD / 'DragonKingdomTycoon.rbxlx').stat().st_mtime, f'Rebuild changed source: {path}'
    contents = {PREFIX + str(path.relative_to(ROOT)): path.read_bytes() for path in files}
    manifest = {
        'format': 1, 'project': 'DRAGON KINGDOM TYCOON',
        'status': report['status'], 'studioAcceptance': 'unrun', 'liveDataStore': 'unrun',
        'passedDomainSecurityPersistenceTests': report['domainSecurityPersistencePassedTests'],
        'passedConnectionTests': report.get('connectionPassedTests', 0),
        'passedCameraTests': report.get('cameraPassedTests', 0),
        'passedPortableTests': report.get('portablePassedTests', report['domainSecurityPersistencePassedTests']),
        'artStatus': 'original_development_assets_pending_roblox_upload_and_final_meshes',
        'previewStatus': 'offline_approximation_not_roblox_studio' if preview.exists() else 'not_included',
        'files': {name: {'bytes': len(content), 'sha256': sha(content)} for name, content in contents.items()},
    }
    manifest_bytes = (json.dumps(manifest, indent=2, ensure_ascii=False) + '\n').encode()
    contents[PREFIX + 'build/package-manifest.json'] = manifest_bytes
    temporary = ARCHIVE.with_suffix('.zip.tmp')
    try:
        with zipfile.ZipFile(temporary, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            for name, data in contents.items():
                info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.external_attr = 0o100644 << 16
                archive.writestr(info, data)
        with zipfile.ZipFile(temporary) as archive:
            assert archive.testzip() is None, 'ZIP CRC failure'
            assert set(archive.namelist()) == set(contents), 'Archive entries differ from selected delivery files'
            for name, expected in manifest['files'].items():
                data = archive.read(name)
                assert len(data) == expected['bytes'] and sha(data) == expected['sha256'], name
        os.replace(temporary, ARCHIVE)
    finally:
        if temporary.exists():
            temporary.unlink()
    (BUILD / 'package-manifest.json').write_bytes(manifest_bytes)
    delivery = {
        'archive': ARCHIVE.name, 'bytes': ARCHIVE.stat().st_size, 'sha256': sha(ARCHIVE.read_bytes()),
        'fileCount': len(contents), 'verified': 'CRC and every manifest SHA256',
        'validationStatus': report['status'],
        'passedDomainSecurityPersistenceTests': report['domainSecurityPersistencePassedTests'],
        'passedConnectionTests': report.get('connectionPassedTests', 0),
        'passedCameraTests': report.get('cameraPassedTests', 0),
        'passedPortableTests': report.get('portablePassedTests', report['domainSecurityPersistencePassedTests']),
    }
    (BUILD / 'delivery.json').write_text(json.dumps(delivery, indent=2) + '\n')
    print(f'PASS delivery: {len(contents)} files; {ARCHIVE.stat().st_size:,} bytes; CRC and all SHA256 verified')
    print(f'Archive: {ARCHIVE}')


if __name__ == '__main__':
    main()
