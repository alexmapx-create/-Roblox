#!/usr/bin/env python3
"""Build the truthful import catalog from original source assets."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re
import struct
import wave

from assets_build import ICON_NAMES

ROOT = Path(__file__).resolve().parents[1]
PORTRAIT_TILE = {
    "cinder_mane":0, "ember_wing":8, "coral_fin":9, "tide_mist":1,
    "moss_antler":2, "petal_bloom":10, "pebble_back":3, "dune_ram":11,
    "volt_quill":4, "storm_kite":12, "frost_crown":5, "glacial_tail":13,
    "dusk_veil":6, "obsidian_fang":14, "dawn_song":7, "prism_hart":16,
    "aether_coil":18, "crown_flare":15, "nebula_tide":17, "solstice_soul":19,
}
SOUNDS = {"music":"fantasyAmbient", **{name:name for name in ["button","coin","hatch","levelUp","dragon","battle","error"]}}


def metadata(file):
    path=ROOT/file
    data=path.read_bytes()
    result={"file":file,"sha256":hashlib.sha256(data).hexdigest(),"bytes":len(data),"license":"original_project_asset","id":"","status":"pending_upload"}
    if file.endswith(".png"):
        if data[:8]!=b"\x89PNG\r\n\x1a\n":
            raise ValueError(f"Not a PNG: {file}")
        width,height=struct.unpack(">II",data[16:24])
        result["width"],result["height"]=width,height
    elif file.endswith(".wav"):
        with wave.open(str(path)) as audio:
            result.update(sampleRate=audio.getframerate(),channels=audio.getnchannels(),sampleBits=audio.getsampwidth()*8,duration=round(audio.getnframes()/audio.getframerate(),3))
    return result


def main():
    dragon_source=(ROOT/"src/shared/Config/Dragons.luau").read_text()
    species=re.findall(r'^\s*\{"([a-z_]+)", "([^"]+)", "([a-z]+)"',dragon_source,re.M)
    if {row[0] for row in species}!=set(PORTRAIT_TILE):
        raise ValueError("Canonical dragon list changed: update portrait mappings explicitly")
    atlas=metadata("art/portraits/dragon-portraits-atlas.png")
    width,height=atlas["width"],atlas["height"]
    xbounds=[round(i*width/5) for i in range(6)]
    ybounds=[round(i*height/4) for i in range(5)]
    portraits={}
    for identifier,name,element in species:
        tile=PORTRAIT_TILE[identifier]
        col,row=tile%5,tile//5
        portraits[identifier]={**atlas,"name":name,"element":element,"tile":tile,"rectOffset":[xbounds[col],ybounds[row]],"rectSize":[xbounds[col+1]-xbounds[col],ybounds[row+1]-ybounds[row]],"atlasSize":[width,height],"artStatus":"original_illustrated_concept_pending_model_consistency_review"}
    catalog={
        "schemaVersion":1,
        "game":"Dragon Kingdom Tycoon",
        "rights":"Original assets made for this project; see art/LICENSE.md. No copied game assets.",
        "publicationState":"local_sources_only_no_roblox_uploaded_ids_available",
        "icons":{name:{**metadata(f"art/icons/{name}.png"),"source":f"art/source/icons/{name}.svg","artStatus":"original_vector_development_art"} for name in ICON_NAMES},
        "portraits":portraits,
        "sounds":{name:{**metadata(f"art/audio/{file}.wav"),"artStatus":"original_synthesized_development_audio"} for name,file in SOUNDS.items()},
        "concepts":{"keyArt":{**metadata("art/concepts/floating-kingdom-key-art.png"),"artStatus":"concept_illustration_not_game_screenshot"}},
        "meshes":{identifier:{"id":"","status":"pending_custom_mesh","file":"","proceduralReference":identifier,"missing":["artist-authored rigged custom mesh","material/texture authoring","nine final animation clips","LOD and mobile budgets validation"]} for identifier,_,_ in species},
        "outstanding":["Owner upload and moderation of 43 PNG icons, one portrait atlas and eight WAV files","Assign uploaded IDs with tools/assets_bind.py","Validate atlas pixel dimensions after Roblox processing","Review portrait consistency against final species meshes","Create and bind artist-authored dragon meshes/materials/animations","Evaluate final audio mix and music loop on target devices","Studio visual/performance validation on desktop/mobile/tablet"],
    }
    (ROOT/"art/manifest.json").write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+"\n")
    template={"schemaVersion":1,"icons":{name:"" for name in ICON_NAMES},"portraitAtlas":"","portraits":{},"sounds":{name:"" for name in SOUNDS},"meshes":{identifier:"" for identifier,_,_ in species},"concepts":{"keyArt":""},"atlasSize":[width,height]}
    (ROOT/"art/uploads.template.json").write_text(json.dumps(template,ensure_ascii=False,indent=2)+"\n")
    print(f"Cataloged {len(ICON_NAMES)} icons, {len(portraits)} mapped portraits, {len(SOUNDS)} WAV files, one concept, and {len(species)} pending custom meshes")


if __name__=="__main__":
    main()
