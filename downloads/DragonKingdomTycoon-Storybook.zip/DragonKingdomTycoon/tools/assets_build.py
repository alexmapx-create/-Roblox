#!/usr/bin/env python3
"""Generate original scalable interface artwork and render transparent PNGs.

This draws original artwork from SVG geometry; it does not edit generated images.
Requirements: Python 3 and Inkscape. Output is deterministic.
"""
from __future__ import annotations

import argparse
import os
from pathlib import Path
import subprocess
import shutil

ROOT = Path(__file__).resolve().parents[1]
ICON_NAMES = [
    "gold", "food", "gems", "level", "settings", "quest", "achievement",
    "social", "collection", "news", "events", "daily", "offers", "storage",
    "dragons", "build", "shop", "battle", "breeding", "hatchery", "farm",
    "expand", "resetCamera", "fire", "water", "nature", "earth", "electric",
    "ice", "dark", "light", "legendary", "close", "confirm", "back", "feed",
    "move", "sell", "collectAll", "music", "sound", "graphics", "profile",
]


def path(d, fill, stroke="#263452", width=7, extra=""):
    return f'<path d="{d}" fill="{fill}" stroke="{stroke}" stroke-width="{width}" stroke-linecap="round" stroke-linejoin="round" {extra}/>'


def circle(x, y, r, fill, stroke="none", width=0):
    return f'<circle cx="{x}" cy="{y}" r="{r}" fill="{fill}" stroke="{stroke}" stroke-width="{width}"/>'


def ellipse(x, y, rx, ry, fill, stroke="none", width=0):
    return f'<ellipse cx="{x}" cy="{y}" rx="{rx}" ry="{ry}" fill="{fill}" stroke="{stroke}" stroke-width="{width}"/>'


def star(x=256, y=240, size=1, fill="url(#gold)"):
    return f'<g transform="translate({x} {y}) scale({size})">' + path("M0 -88 24 -30 86 -27 40 15 53 77 0 45 -53 77 -40 15 -86 -27 -24 -30Z", fill, "#986326", 6) + path("M0 -63 16 -20 61 -20 28 10 34 54 0 32 -34 54 -28 10 -61 -20 -16 -20Z", "#FFF4BC", "none", 0, 'opacity=".48"') + "</g>"


def crystal(x, y, scale=1, color="pink", angle=0):
    return f'<g transform="translate({x} {y}) rotate({angle}) scale({scale})">' + path("M-48 -65 39 -65 75 -12 0 83 -72 -12Z", f"url(#{color})", "#4C3E72", 5) + path("M-48 -65 -18 -12 0 83 39 -65 24 -12 -72 -12H75", "none", "#FFF0FF", 3, 'opacity=".58"') + path("M-35 -58 26 -58 -16 -20Z", "#FFFFFF", "none", 0, 'opacity=".55"') + "</g>"


def leaf(x, y, scale=1, angle=0):
    return f'<g transform="translate({x} {y}) rotate({angle}) scale({scale})">' + path("M0 68C-98 18-69-53 12-68 39-12 63 42 0 68Z", "url(#green)", "#27625B", 5) + path("M0 68Q-10 12 12-68M-3 15-43-12M2-18 20-35", "none", "#C1F392", 4) + "</g>"


def scroll():
    return path("M147 151Q116 127 115 166V313Q111 355 149 351H344V171Q344 134 310 143H147Z", "url(#paper)", "#92653B", 8) + path("M150 144Q161 164 142 181H115M149 349Q125 343 129 320H340Q365 319 356 347Q354 365 327 361", "url(#gold)", "#92653B", 7) + path("M177 199H296M177 222H307M177 245H286M177 269H245", "none", "#AF8761", 7)


def dragon(x=260, y=260, scale=1, color="green", mirror=False):
    flip = -1 if mirror else 1
    return f'<g transform="translate({x} {y}) scale({scale * flip} {scale})">' + path("M-62 94Q-77 63-65 10L-91-38-42-23-52-85-10-43 20-55Q55-63 75-32L110-8Q135 22 108 40L62 45Q68 87 18 104Z", f"url(#{color})", "#324359", 7) + path("M20-55 44-88Q49-52 63-41M-42-23-25-78Q-4-48 3-38", "url(#gold)", "#6B593E", 5) + path("M-49 35Q-70 62-111 71L-92 35-139 34-105 6-112-22-55-8Z", "url(#blue)", "#31516F", 5) + path("M54 49Q32 52 15 71L17 99 50 89Z", "url(#paper)", "none", 0) + ellipse(50, -12, 18, 22, "#FFFCE8", "#3C514F", 4) + ellipse(55, -10, 8, 14, "#233448") + circle(58, -16, 3, "#FFFFFF") + ellipse(99, 14, 4, 6, "#344E54") + path("M77 36Q88 40 101 31", "none", "#405546", 4) + "</g>"


def sword(x, y, angle):
    return f'<g transform="translate({x} {y}) rotate({angle})">' + path("M-14 35-21-130 0-167 21-130 14 35Z", "url(#silver)", "#426180", 6) + path("M0-154V29", "none", "#E4FEFF", 4) + path("M-55 37Q-37 22 0 28Q37 22 55 37L46 53 19 46 17 116H-17L-19 46-46 53Z", "url(#gold)", "#8F6638", 6) + path("M-13 73H13M-13 90H13", "none", "#8F6638", 4) + circle(0, 123, 21, "url(#pink)", "#92653B", 5) + "</g>"


def gift():
    return path("M133 237H377V350Q256 386 133 350Z", "url(#pink)", "#654579", 7) + path("M123 217Q254 187 386 217V253Q254 281 123 252Z", "url(#pink)", "#654579", 7) + path("M235 205H278V366H235Z", "url(#gold)", "#8F633D", 5) + path("M253 205Q147 216 155 165Q164 118 212 153L253 205Q317 123 344 156Q382 210 253 205Z", "url(#gold)", "#98663B", 6) + path("M244 196Q191 172 181 166M266 198 328 168", "none", "#FFEFD0", 7)


def chest():
    return path("M129 253H384L370 346Q256 383 142 346Z", "url(#wood)", "#624438", 8) + path("M123 254Q127 170 203 158H306Q379 174 387 253Z", "url(#wood)", "#624438", 8) + path("M162 190 159 351M346 191 350 351M129 251H385", "none", "url(#gold)", 18) + path("M242 237H280V306H242Z", "url(#gold)", "#785331", 5) + circle(261, 265, 7, "#51393F") + path("M171 193Q209 174 315 187", "none", "#EAB081", 5)


def fruit(x, y, scale=1):
    return f'<g transform="translate({x} {y}) scale({scale})">' + path("M0-47Q45-72 75-37Q99 4 60 57Q16 101-27 63Q-68 30-51-13Q-40-57 0-47Z", "url(#red)", "#954B40", 6) + path("M-2-46Q-3-77 23-99", "none", "#79523B", 9) + leaf(30, -65, .37, 74) + path("M-33-19Q-44 4-28 31", "none", "#FFC5A1", 12, 'opacity=".75"') + "</g>"


def tower():
    return path("M174 245H337V367H174Z", "url(#paper)", "#776246", 7) + path("M142 241 256 136 371 241Z", "url(#blue)", "#3D5780", 7) + path("M198 233 258 175 316 232M203 205H308", "none", "#91E5F7", 7) + path("M232 366V293Q255 262 279 293V366Z", "url(#wood)", "#776246", 6) + path("M187 361H328M164 374H349", "none", "url(#gold)", 11) + path("M256 142V109M256 108 301 121 256 134", "url(#pink)", "#725780", 5)


def motif(name):
    if name in ("gold", "sell", "collectAll"):
        s = ""
        for x,y,r in [(195,291,60),(304,296,72),(254,210,75)]:
            s += ellipse(x+2,y+12,r,r*.91,"#986030") + circle(x,y,r,"url(#gold)","#A96D2F",6) + circle(x,y,r*.78,"none","#FDEBBC",4) + star(x,y,.4)
        return s + (path("M123 325Q191 391 326 340L311 312M326 340 301 367", "none", "#AEEDB4", 13) if name == "collectAll" else "")
    if name in ("food", "feed"):
        return leaf(182,265,.7,-36)+fruit(256,263,1.3)+circle(180,310,33,"url(#pink)","#814C77",4)+circle(159,282,29,"url(#pink)","#814C77",4)+circle(197,273,32,"url(#pink)","#814C77",4)+leaf(172,234,.42,54)
    if name == "gems":
        return crystal(188,280,.9,"blue",-21)+crystal(291,255,1.37,"pink",9)+star(358,171,.24,"#FFF8CB")
    if name in ("level", "achievement"):
        if name == "level":
            return path("M151 176Q256 209 361 176V261Q348 336 256 383 165 335 151 261Z","url(#blue)","#BD8B44",12)+path("M164 187Q108 154 99 207L138 223 106 247 148 265M348 187Q404 154 413 207L374 223 406 247 364 265","url(#silver)","#56748B",5)+star(256,260,1)
        return path("M177 168H334L313 276Q258 324 202 276Z","url(#gold)","#9C672E",6)+path("M176 185H134Q119 255 193 256M334 185H378Q393 255 319 256","none","url(#gold)",20)+path("M256 305V343M207 357H309","none","url(#gold)",22)+star(256,223,.49)
    if name in ("settings", "graphics"):
        teeth = ""
        for angle in range(0,360,45):
            teeth += f'<g transform="rotate({angle} 256 256)"><path d="M239 119H273L279 177H233Z" fill="url(#silver)" stroke="#3F6685" stroke-width="5"/></g>'
        return teeth+circle(256,256,103,"url(#silver)","#3F6685",7)+circle(256,256,61,"url(#blue)","#F5DFC5",8)+crystal(256,251,.54,"blue")
    if name in ("quest", "news"):
        return scroll()+(star(276,295,.43) if name == "quest" else path("M282 300Q329 251 369 155Q330 152 301 210L272 276Z","url(#blue)","#4E6778",4)+path("M283 292 350 178M300 238 334 224","none","#DCF7FB",4))
    if name in ("social", "profile"):
        s=""
        for x,y,scale in ([(174,246,.7),(338,242,.7),(256,284,1)] if name=="social" else [(256,267,1.32)]):
            s += f'<g transform="translate({x} {y}) scale({scale})">'+path("M-57 63Q-67 1-28-13H28Q67 1 57 63Z","url(#blue)","#385475",6)+circle(0,-48,38,"url(#paper)","#8E6D51",5)+path("M-35-65Q-15-116 32-82L39-59Q7-86-34-48Z","url(#wood)","#714C3C",4)+"</g>"
        return s
    if name == "collection":
        return path("M134 163Q206 142 253 170L257 369Q190 343 136 363ZM253 170Q306 143 376 164L374 362Q306 343 257 369Z","url(#paper)","#795A48",8)+path("M135 162 126 158V360L256 384 386 361V158L375 163","none","url(#gold)",13)+dragon(213,258,.43)+star(324,246,.5)
    if name == "events":
        return circle(256,267,111,"url(#gold)","#916335",9)+circle(256,267,87,"url(#paper)","#AF8050",5)+path("M256 199V268L301 289","none","#577C95",13)+circle(256,267,10,"url(#blue)")+path("M233 139H279M256 139V155","none","url(#gold)",15)+star(358,174,.36,"#FFFAC7")
    if name in ("daily", "offers"):
        return gift()+(star(344,287,.45) if name=="offers" else "")
    if name == "storage": return chest()
    if name == "dragons": return dragon(270,266,1.15)
    if name == "build": return tower()+path("M140 183 197 232 179 253 124 209Z","url(#wood)","#694839",5)+path("M108 168 125 145 164 175 155 198Z","url(#silver)","#547087",5)
    if name == "shop":
        return path("M134 225H380V358H134Z","url(#paper)","#79573C",7)+path("M124 178H390L406 242Q384 277 352 245 320 277 288 245 256 277 224 245 192 277 160 245 131 274 108 242Z","url(#red)","#79573C",6)+path("M163 178 155 244M224 178V246M288 178V246M351 178 357 244","none","#FFF0C3",24)+path("M229 357V294H287V357M154 283H207V327H154M311 283H364V327H311","url(#blue)","#8F6D49",6)+path("M245 161H276","none","url(#gold)",11)
    if name == "battle": return sword(254,259,-43)+sword(254,259,43)+star(256,344,.35,"#FFFFFF")
    if name == "breeding":
        return dragon(195,288,.76,"blue")+dragon(330,290,.76,"pink",True)+path("M256 222Q200 184 220 154Q244 139 256 161Q271 136 293 154Q312 185 256 222Z","url(#pink)","#835071",5)
    if name == "hatchery":
        return ellipse(257,344,123,32,"url(#wood)","#765037",7)+path("M153 329Q139 361 208 367M189 324Q177 369 290 371M284 330Q379 331 358 356","none","#E0AB72",13)+path("M174 277Q174 183 258 135Q339 192 339 277Q336 344 256 350Q176 344 174 277Z","url(#paper)","#A07E57",7)+path("M219 180 263 240 299 223 278 273 317 319","none","#AAC0AB",7)+crystal(226,281,.24,"green",-14)+crystal(287,181,.21,"green")
    if name == "farm":
        return path("M130 320Q255 283 381 320L359 375H151Z","url(#wood)","#705443",7)+path("M162 337H348M174 358H337","none","#D9B380",5)+path("M255 327V180M255 256 190 230M256 274 322 248","none","#548D4E",14)+leaf(192,212,.63,-56)+leaf(314,231,.65,53)+fruit(252,222,.71)+leaf(266,159,.55,3)
    if name == "expand":
        return path("M123 174 208 147 297 174 387 146V339L297 368 208 341 123 367Z","url(#paper)","#8D6F4B",7)+path("M207 151V338M298 178V365","none","#CAB994",4)+path("M146 227Q206 281 239 220T369 259M155 313 218 283 292 319 347 289","none","#81B9B0",12)+star(260,255,.65)+path("M336 128V188M306 158H365","none","#75C0D7",12)
    if name == "resetCamera":
        return path("M135 211H192L214 178H294L318 211H375V339H135Z","url(#blue)","#476380",8)+circle(260,275,68,"url(#silver)","#3B5A7C",8)+circle(260,275,44,"url(#blue)","#B5F6F5",5)+circle(245,260,12,"#EDFEFF")+path("M163 168Q257 97 358 170L325 172M358 170 355 138","none","url(#gold)",14)
    if name == "fire":
        return path("M260 135Q285 205 328 196Q323 254 369 294Q356 378 256 380Q155 372 145 298Q166 241 219 207L226 270Q267 223 260 135Z","url(#red)","#A65539",7)+path("M256 237Q285 284 313 308Q322 354 255 358Q195 352 202 305Q224 283 256 237Z","url(#gold)","none",0)
    if name == "water":
        return path("M256 139Q198 216 163 286Q145 372 256 387Q370 378 352 286Q315 208 256 139Z","url(#blue)","#366590",7)+path("M215 245Q183 291 198 320","none","#C9F8FF",18)+path("M191 352Q255 380 318 345","none","#82DDED",6)
    if name == "nature": return leaf(250,260,1.5,16)+leaf(319,316,.75,74)
    if name == "earth":
        return path("M133 316 173 211 228 226 274 163 340 216 380 337 269 373 165 352Z","url(#wood)","#715B45",7)+path("M173 211 208 318 274 163 279 316 340 216M208 318 269 373 279 316 380 337","none","#DCB892",6)+crystal(246,290,.32,"green")
    if name == "electric":
        return path("M263 136H338L281 234H338L183 383 225 270H173Z","url(#gold)","#997041",8)+path("M278 158 232 250H284L217 330","none","#FFF6B6",6)
    if name == "ice":
        s = ""
        for a in range(0,360,60):
            s += f'<g transform="rotate({a} 256 256)">'+path("M256 129V256M222 158 256 188 290 158M223 208 256 231 289 208","none","#619BCC",16)+path("M256 133V256M225 159 256 187 287 159","none","#D5FAFF",8)+"</g>"
        return s+crystal(256,250,.39,"blue")
    if name == "dark":
        return path("M270 144Q156 120 141 249Q138 359 244 378Q349 394 385 288Q332 330 278 303Q199 258 270 144Z","url(#pink)","#59406B",8)+star(328,208,.44,"#DBC5FF")+circle(376,174,7,"#D6C4FF")
    if name in ("light", "legendary"):
        if name == "legendary":
            return path("M146 305 126 188 204 236 254 140 306 236 384 188 362 305Z","url(#gold)","#996B36",8)+path("M152 304H358V347H152Z","url(#gold)","#996B36",7)+crystal(256,274,.45,"pink")+circle(149,214,10,"#CBF4FF")+circle(365,214,10,"#CBF4FF")
        s=""
        for a in range(0,360,45):
            s += f'<g transform="rotate({a} 256 256)">'+path("M256 122V161","none","url(#gold)",13)+"</g>"
        return s+circle(256,256,81,"url(#gold)","#A8773F",7)+star(256,257,.72,"#FFF6CB")
    if name == "close": return path("M178 180 333 334M333 180 178 334","none","url(#paper)",35)
    if name == "confirm": return path("M153 253 229 325 360 179","none","url(#green)",38)+path("M164 245 231 309 351 180","none","#C2F8C0",7)
    if name == "back": return path("M258 174 159 258 258 342V290H356V225H258Z","url(#silver)","#496888",7)
    if name == "move":
        return path("M235 224V178H205L256 128 307 178H277V224H327V194L378 256 327 316V287H277V334H307L256 384 205 334H235V287H184V316L134 256 184 194V224Z","url(#silver)","#4D7D92",7)
    if name == "music":
        return path("M225 163 346 140V309Q338 344 300 341Q253 330 283 300Q309 284 327 294V204L244 222V339Q220 376 182 360Q151 344 180 320Q210 305 225 315Z","url(#gold)","#99703F",7)
    if name == "sound":
        return path("M151 222H208L277 163V354L208 294H151Z","url(#blue)","#4F6B86",7)+path("M309 213Q351 257 309 303M335 180Q405 259 335 336","none","url(#gold)",15)
    raise ValueError(name)


def artwork(name):
    palette = {"gold":"#345D89","food":"#335F55","gems":"#57477B","battle":"#694754","build":"#355E80","breeding":"#6E466E","farm":"#325F50","fire":"#6C453C","dark":"#513E78"}
    base = palette.get(name, "#355C7C")
    defs = f'''<defs>
<linearGradient id="plate" x2="0" y2="1"><stop stop-color="#A9E7E9"/><stop offset=".15" stop-color="{base}"/><stop offset="1" stop-color="#152B45"/></linearGradient>
<linearGradient id="gold" x2=".25" y2="1"><stop stop-color="#FFF5CF"/><stop offset=".28" stop-color="#FFE19A"/><stop offset=".58" stop-color="#D8A54F"/><stop offset=".8" stop-color="#F4CD75"/><stop offset="1" stop-color="#A86D35"/></linearGradient>
<linearGradient id="blue" x2=".5" y2="1"><stop stop-color="#D0FCFF"/><stop offset=".33" stop-color="#74D6F0"/><stop offset=".7" stop-color="#448BBC"/><stop offset="1" stop-color="#426AA2"/></linearGradient>
<linearGradient id="green" x2=".5" y2="1"><stop stop-color="#DEF3A3"/><stop offset=".35" stop-color="#91CE71"/><stop offset="1" stop-color="#3C9474"/></linearGradient>
<linearGradient id="pink" x2=".25" y2="1"><stop stop-color="#FDE7FF"/><stop offset=".36" stop-color="#E59BE4"/><stop offset=".68" stop-color="#A86DC2"/><stop offset="1" stop-color="#674F99"/></linearGradient>
<linearGradient id="red" x2=".3" y2="1"><stop stop-color="#FFD697"/><stop offset=".32" stop-color="#F38D64"/><stop offset=".72" stop-color="#D75C65"/><stop offset="1" stop-color="#AB4365"/></linearGradient>
<linearGradient id="silver" x2=".6" y2="1"><stop stop-color="#FAFFFF"/><stop offset=".35" stop-color="#C4E8EF"/><stop offset=".7" stop-color="#88B9CE"/><stop offset="1" stop-color="#6686AA"/></linearGradient>
<linearGradient id="wood" x2=".3" y2="1"><stop stop-color="#DFBB8E"/><stop offset=".35" stop-color="#B88660"/><stop offset="1" stop-color="#8B5D48"/></linearGradient>
<linearGradient id="paper" x2=".2" y2="1"><stop stop-color="#FFFCE7"/><stop offset=".6" stop-color="#F1DBAD"/><stop offset="1" stop-color="#C9AC7C"/></linearGradient>
<radialGradient id="glow"><stop stop-color="#BDEFFF" stop-opacity=".45"/><stop offset="1" stop-color="#BDEFFF" stop-opacity="0"/></radialGradient>
<filter id="shadow" x="-.3" y="-.3" width="1.6" height="1.6"><feDropShadow dx="0" dy="7" stdDeviation="5" flood-color="#13233D" flood-opacity=".55"/></filter>
</defs>'''
    frame = path("M256 52Q305 51 351 80L387 82 398 119Q442 169 444 230L460 256 444 284Q439 349 397 397L387 431 350 435Q305 460 256 460Q206 460 161 435L126 431 115 397Q70 349 69 284L52 256 69 230Q69 169 115 119L126 82 161 80Q206 51 256 52Z", "url(#gold)", "#735435", 7)
    frame += circle(256,256,181,"url(#plate)","#F1D298",6)+circle(256,250,165,"none","#76A4B9",2)+circle(256,230,171,"url(#glow)")
    frame += path("M123 140Q180 79 260 79Q346 83 392 145", "none", "#FFF4CB", 7, 'opacity=".8"')
    for x,y in [(256,67),(256,444),(68,256),(444,256)]:
        frame+=circle(x,y,14,"url(#blue)","#9C733B",4)+circle(x-3,y-4,4,"#FFF9D9")
    decorative = path("M128 367Q157 399 186 400M325 401Q355 399 385 367", "none", "#D7B980", 5)
    # feDropShadow is inconsistently implemented in Linux SVG renderers.
    # A geometry shadow keeps the illustration visible in every supported renderer.
    artwork_layer = f'<g transform="translate(0 7)" opacity=".18">{motif(name)}</g><g>{motif(name)}</g>'
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 512 512"><title>Original {name} fantasy game icon</title>{defs}{frame}{decorative}{artwork_layer}</svg>'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--svg-only", action="store_true")
    parser.add_argument("--size", type=int, default=512)
    args = parser.parse_args()
    if not 128 <= args.size <= 2048:
        parser.error("PNG size must be between 128 and 2048")
    source = ROOT / "art/source/icons"
    dest = ROOT / "art/icons"
    source.mkdir(parents=True, exist_ok=True)
    dest.mkdir(parents=True, exist_ok=True)
    renderer = shutil.which("inkscape")
    if not renderer and not args.svg_only:
        parser.error("Inkscape required to render PNG. Use --svg-only to create vector sources.")
    env = dict(os.environ, XDG_CACHE_HOME="/tmp/dragon-art-cache", XDG_CONFIG_HOME="/tmp/dragon-art-config")
    for name in ICON_NAMES:
        svg = source / f"{name}.svg"
        svg.write_text(artwork(name), encoding="utf-8")
        if not args.svg_only:
            result = subprocess.run([renderer, str(svg), "--export-type=png", f"--export-filename={dest / (name + '.png')}", f"--export-width={args.size}", f"--export-height={args.size}", "--export-background-opacity=0"], env=env, capture_output=True, text=True)
            if result.returncode:
                raise RuntimeError(result.stderr)
    print(f"Generated {len(ICON_NAMES)} original SVG icons" + (" and transparent PNGs" if not args.svg_only else ""))


if __name__ == "__main__":
    main()
