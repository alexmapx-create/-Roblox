#!/usr/bin/env python3
"""Synthesize original fantasy development music and feedback; no sampled sources.

This is development audio, awaiting Roblox moderation/upload and listening tests.
Requires Python 3 + NumPy; deterministic, 44.1 kHz 16-bit stereo WAV output.
"""
from __future__ import annotations

from pathlib import Path
import wave
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
RATE = 44100
RNG = np.random.default_rng(63021)


def frequency(midi):
    return 440 * 2 ** ((midi - 69) / 12)


def voice(midi, seconds, style="bell"):
    t = np.arange(round(seconds * RATE)) / RATE
    f = frequency(midi)
    if style == "bell":
        signal = np.sin(2*np.pi*f*t)*np.exp(-t*2.8)
        signal += .26*np.sin(2*np.pi*f*2.006*t)*np.exp(-t*4.3)
        signal += .13*np.sin(2*np.pi*f*3.011*t)*np.exp(-t*6.1)
    elif style == "flute":
        vibrato = 1 + .0018*np.sin(2*np.pi*4.2*t)
        signal = np.sin(2*np.pi*f*t*vibrato)
        signal += .13*np.sin(2*np.pi*f*2*t)
        signal *= np.sin(np.pi*np.clip(t/seconds,0,1))**1.5
    elif style == "pad":
        signal = np.sin(2*np.pi*f*t) + .15*np.sin(2*np.pi*f*1.997*t)
        signal += .08*np.sin(2*np.pi*f*3.006*t)
        signal *= np.sin(np.pi*t/seconds)**.8
    else:
        raise ValueError(style)
    attack = np.minimum(t/.015, 1)
    release = np.minimum((seconds-t)/.06,1)
    return signal*attack*release


def add(track, sound, seconds, gain=1, pan=0):
    start = round(seconds * RATE)
    end = min(len(track),start+len(sound))
    if start >= len(track):
        return
    chunk = sound[:end-start]*gain
    track[start:end,0] += chunk*np.sqrt((1-pan)/2)
    track[start:end,1] += chunk*np.sqrt((1+pan)/2)


def save(name, track):
    maximum = np.max(np.abs(track))
    if maximum > .87:
        track = track*(.87/maximum)
    track = np.tanh(track)*.9
    data = np.round(track*32767).astype("<i2")
    folder = ROOT / "art/audio"
    folder.mkdir(parents=True,exist_ok=True)
    with wave.open(str(folder/f"{name}.wav"),"wb") as file:
        file.setnchannels(2)
        file.setsampwidth(2)
        file.setframerate(RATE)
        file.writeframes(data.tobytes())


def music():
    duration = 32.0
    track = np.zeros((round(duration*RATE),2))
    chords = [[48,55,60,64,71],[45,52,57,60,67],[41,48,53,57,64],[43,50,55,59,64]]*2
    for bar,chord in enumerate(chords):
        offset=bar*4
        for note in chord:
            add(track,voice(note,4,"pad"),offset,.055,(note%3-1)*.3)
        for step in range(8):
            note=chord[[2,3,4,3,2,1,3,4][step]]+12
            add(track,voice(note,1.4),offset+step*.5,.07,np.sin(step*1.5)*.65)
        add(track,voice(chord[0]-12,4,"pad"),offset,.07)
        for step,note in enumerate([chord[2]+12,chord[4]+12]):
            add(track,voice(note,1.9,"flute"),offset+step*2,.028,.2)
    # Small alternating echoes of the harp make a quiet spacious backdrop.
    dry=track.copy()
    for delay,gain in [(int(.31*RATE),.16),(int(.62*RATE),.07)]:
        track[delay:]+=dry[:-delay,::-1]*gain
    edge=int(.08*RATE)
    track[:edge]*=np.linspace(0,1,edge)[:,None]
    track[-edge:]*=np.linspace(1,0,edge)[:,None]
    save("fantasyAmbient",track)


def feedback():
    recipes = {
        "button":(.22,[(84,0,.10),(91,.055,.055)]),
        "coin":(.9,[(84,0,.13),(88,.08,.1),(91,.16,.11),(96,.24,.08)]),
        "hatch":(1.6,[(60,0,.08),(64,.16,.09),(67,.33,.12),(72,.52,.13),(79,.78,.09)]),
        "levelUp":(1.8,[(72,0,.11),(76,.15,.12),(79,.30,.12),(84,.48,.13),(88,.68,.11),(91,.88,.09)]),
        "battle":(.95,[(48,0,.11),(55,.06,.12),(60,.17,.08),(67,.30,.07)]),
        "error":(.45,[(64,0,.05),(60,.16,.05)]),
    }
    for name,(duration,notes) in recipes.items():
        track=np.zeros((round(duration*RATE),2))
        for note,start,gain in notes:
            add(track,voice(note,min(.65,duration-start)),start,gain)
        save(name,track)
    duration=1.4
    t=np.arange(round(duration*RATE))/RATE
    envelope=np.sin(np.pi*t/duration)**2
    phase=2*np.pi*(120*t-18*t*t)
    signal=(np.sin(phase)+.28*np.sin(phase*2)+.11*np.sin(phase*3))*.12*envelope
    signal+=RNG.normal(0,.008,len(t))*envelope
    track=np.zeros((len(t),2))
    add(track,signal,0,1)
    save("dragon",track)


if __name__ == "__main__":
    music()
    feedback()
    print("Generated original 32-second ambient loop and seven feedback WAV files")
