#!/usr/bin/env python3
"""Render an explicitly offline preview from the project's real scene and GUI data.

Requires Blender 4.x, Pillow and the Luau CLI. This is a geometry/material/layout
approximation, not a Roblox Studio screenshot or a rendering acceptance test.
No reference artwork or invented world/UI content is used.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]


def load_tool(name: str):
    spec = importlib.util.spec_from_file_location(name, ROOT / "tools" / f"{name}.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def lua_json_function() -> str:
    return r'''
local function encode(value)
 local kind=type(value)
 if kind=="nil" then return "null" end
 if kind=="string" then return string.format("%q",value):gsub("\\\n","\\n") end
 if kind=="number" or kind=="boolean" then return tostring(value) end
 if kind~="table" then return "null" end
 local parts={}
 if #value>0 then for _,v in value do table.insert(parts,encode(v))end;return "["..table.concat(parts,",").."]" end
 for key,v in value do if type(key)=="string" and type(v)~="function" then table.insert(parts,encode(key)..":"..encode(v))end end
 table.sort(parts);return "{"..table.concat(parts,",").."}"
end
'''


def run_luau(source: str, binary: str) -> list[dict]:
    (ROOT / "build").mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="visual-preview-", dir=ROOT / "build") as temporary:
        script = Path(temporary) / "export.luau"
        script.write_text(source)
        result = subprocess.run([binary, str(script)], cwd=ROOT, capture_output=True, text=True)
        if result.returncode:
            raise RuntimeError(result.stderr.strip() or result.stdout.strip())
        return [json.loads(line.removeprefix("PREVIEW:")) for line in result.stdout.splitlines() if line.startswith("PREVIEW:")]


def scene_parts(binary: str) -> list[dict]:
    parts = []
    xml = ET.parse(ROOT / "src/models/IslandTemplate.rbxmx")
    for item in xml.findall(".//Item"):
        if item.attrib["class"] not in ("Part", "WedgePart"):
            continue
        props = item.find("Properties")
        transparency = float(props.findtext("float[@name='Transparency']", "0"))
        name = props.findtext("string[@name='Name']", "Part")
        # These decorative preview contents are removed by the real createIsland.
        if transparency >= .995 or name in {"WelcomeEgg", "EggGoldenSpot", "EmeraldCropLeaf", "Sunberry"}:
            continue
        size = props.find("Vector3[@name='Size']")
        cf = props.find("CoordinateFrame[@name='CFrame']")
        color = props.find("Color3[@name='Color']")
        shape = props.findtext("token[@name='shape']", "1")
        parts.append({"name": name, "shape": "Wedge" if item.attrib["class"] == "WedgePart" else {"0": "Ball", "1": "Block", "2": "Cylinder"}[shape],
                      "size": [float(size.findtext(axis)) for axis in "XYZ"],
                      "position": [float(cf.findtext(axis)) + (80 if axis == "Y" else 0) for axis in "XYZ"],
                      "rotation": [float(cf.findtext(f"R{row}{column}")) for row in range(3) for column in range(3)],
                      "color": [float(color.findtext(channel)) for channel in "RGB"],
                      "material": props.findtext("token[@name='Material']", "272"), "transparency": transparency, "source": "IslandTemplate.rbxmx"})
    mock = load_tool("world_smoke").MOCK
    dragons = (ROOT / "src/shared/Config/Dragons.luau").read_text()
    art = (ROOT / "src/shared/DragonArt.luau").read_text()
    world = (ROOT / "src/server/Services/WorldBuilder.luau").read_text()
    world = world.replace("require(Shared.Config.Dragons)", "DragonsConfig").replace("require(Shared.Config.Habitats)", "{}").replace("require(Shared.DragonArt)", "DragonArt")
    script = mock + "\nlocal DragonsConfig=(function()\n" + dragons + "\nend)()\nlocal DragonArt=(function()\n" + art + "\nend)()\nlocal WorldBuilder=(function()\n" + world + "\nend)()\n" + lua_json_function() + r'''
local Engine=require("../../src/shared/Engine")
local profile=Engine.newProfile(1791676800)
local island=WorldBuilder.createIsland(player,Vector3.new(0,80,0))
WorldBuilder.syncIsland(player,profile)
for _,p in island.ProfileVisuals:GetDescendants()do
 if p:IsA("BasePart") and (p.Transparency or 0)<.995 then
  local color=p.Color;local cf=p.CFrame
  print("PREVIEW:"..encode({name=p.Name,shape=p.ClassName=="WedgePart" and "Wedge" or p.Shape or "Block",size={p.Size.X,p.Size.Y,p.Size.Z},position={cf.Position.X,cf.Position.Y,cf.Position.Z},rotation=cf._r,color={color.R,color.G,color.B},material=p.Material,transparency=p.Transparency or 0,source="WorldBuilder/DragonArt actual starter profile"}))
 end
end
'''
    parts.extend(run_luau(script, binary))
    return parts


def gui_tree(binary: str, width: int, height: int) -> dict:
    assembled = load_tool("ui_mock").assembled_source(ROOT)
    assembled = assembled[:assembled.index('local hud=find("DragonKingdomHUD")')]
    assembled = assembled.replace("camera.ViewportSize=Vector2.new(1280,720)", f"camera.ViewportSize=Vector2.new({width},{height})")
    assembled += '\nUI.refresh(state)\nUI.connectionStatus({status="ready"})\n' + lua_json_function() + r'''
local keys={"ClassName","Name","Size","Position","AnchorPoint","BackgroundColor3","BackgroundTransparency","Visible","Text","TextColor3","TextSize","TextXAlignment","TextYAlignment","TextStrokeColor3","TextStrokeTransparency","Font","Rotation","ZIndex","LayoutOrder","Scale","CornerRadius","Thickness","Color","Transparency","FillDirection","Padding","HorizontalAlignment","VerticalAlignment","PaddingLeft","PaddingRight","PaddingTop","PaddingBottom","Image","ImageColor3","ImageTransparency"}
local function export(object)
 local result={props={},children={}}
 for _,key in keys do local value=object._props[key];if value~=nil then result.props[key]=value end end
 for _,child in object:GetChildren()do table.insert(result.children,export(child))end
 return result
end
print("PREVIEW:"..encode(export(find("DragonKingdomHUD"))))
'''
    return run_luau(assembled, binary)[0]


def project_camera(binary: str, width: int, height: int) -> dict:
    source = lua_json_function() + f'''
local CameraFit=require("../../src/client/Controllers/CameraFit")
local fit=CameraFit.calculate({{width={width},height={height},insetTop=58}})
print("PREVIEW:"..encode({{target={{fit.offset.x,80+fit.offset.y,fit.offset.z}},yaw=math.deg(fit.yaw),elevation=math.deg(fit.elevation),distance=fit.distance,fov=fit.fieldOfView,source="CameraFit.calculate actual fit; top inset 58"}}))
'''
    return run_luau(source, binary)[0]


def blender_worker(scene_path: Path, target: Path):
    import bpy
    from mathutils import Matrix, Vector

    data = json.loads(scene_path.read_text())
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete(use_global=False)
    scene = bpy.context.scene
    scene.render.engine = "CYCLES"
    scene.cycles.device = "CPU"
    scene.cycles.samples = 48
    scene.cycles.use_denoising = False  # Debian Blender may omit OpenImageDenoise.
    scene.render.resolution_x, scene.render.resolution_y = data["width"], data["height"]
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "PNG"
    scene.render.film_transparent = True
    scene.view_settings.view_transform = "Standard"
    scene.view_settings.look = "Medium High Contrast"
    scene.view_settings.exposure = -.15
    scene.world.use_nodes = True
    background = scene.world.node_tree.nodes.get("Background")
    background.inputs[0].default_value = (.68, .80, .88, 1)
    background.inputs[1].default_value = .75
    transform = Matrix(((1, 0, 0), (0, 0, -1), (0, 1, 0)))
    meshes, materials = {}, {}

    def mesh_for(shape):
        if shape in meshes:
            return meshes[shape]
        if shape == "Ball":
            bpy.ops.mesh.primitive_uv_sphere_add(segments=16, ring_count=8, radius=1)
            obj = bpy.context.object
            mesh = obj.data
            for point in mesh.vertices:
                point.co *= .5
            bpy.data.objects.remove(obj, do_unlink=True)
        elif shape == "Cylinder":
            bpy.ops.mesh.primitive_cylinder_add(vertices=32, radius=.5, depth=1)
            obj = bpy.context.object
            mesh = obj.data
            for point in mesh.vertices:
                x, y, z = point.co
                point.co = (z, x, y)
            bpy.data.objects.remove(obj, do_unlink=True)
        elif shape == "Wedge":
            mesh = bpy.data.meshes.new("RobloxWedge")
            mesh.from_pydata([(-.5,-.5,-.5),(.5,-.5,-.5),(-.5,-.5,.5),(.5,-.5,.5),(-.5,.5,.5),(.5,.5,.5)],[],[(0,2,3,1),(2,4,5,3),(0,1,5,4),(0,4,2),(1,3,5)])
        else:
            bpy.ops.mesh.primitive_cube_add(size=1)
            obj = bpy.context.object
            mesh = obj.data
            bpy.data.objects.remove(obj, do_unlink=True)
        for face in mesh.polygons:
            face.use_smooth = shape in {"Ball", "Cylinder"} and (shape != "Cylinder" or len(face.vertices) == 4)
        meshes[shape] = mesh
        return mesh

    for index, part in enumerate(data["parts"]):
        mesh = mesh_for(part["shape"])
        obj = bpy.data.objects.new(f'{index}_{part["name"]}', mesh)
        scene.collection.objects.link(obj)
        r = part["rotation"]
        rotation = Matrix([r[0:3], r[3:6], r[6:9]])
        world = (transform @ rotation).to_4x4()
        world.translation = transform @ Vector(part["position"])
        obj.matrix_world = world
        obj.scale = part["size"]
        key = (*part["color"], part["material"], part["transparency"])
        if key not in materials:
            material = bpy.data.materials.new(f"Palette_{len(materials)}")
            material.use_nodes = True
            shader = material.node_tree.nodes.get("Principled BSDF")
            # Roblox exported Color3 channels are sRGB display colors. Blender
            # node sockets take linear light; treating them as linear washes out
            # the project's actual warm/saturated palette.
            linear = tuple(c/12.92 if c<=.04045 else ((c+.055)/1.055)**2.4 for c in part["color"])
            shader.inputs["Base Color"].default_value = (*linear, 1)
            shader.inputs["Roughness"].default_value = .78
            if part["material"] in {"Neon", "288"}:
                shader.inputs["Emission Color"].default_value = (*linear, 1)
                shader.inputs["Emission Strength"].default_value = .25
            shader.inputs["Alpha"].default_value = 1-part["transparency"]
            materials[key] = material
        # Object material link avoids assigning the palette to every shared mesh.
        if not mesh.materials:
            mesh.materials.append(materials[key])
        obj.material_slots[0].link = "OBJECT"
        obj.material_slots[0].material = materials[key]
    sun = bpy.data.lights.new("Warm morning sun", "SUN")
    sun.energy = 2.0
    sun.angle = math.radians(8)
    light = bpy.data.objects.new("Warm morning sun", sun)
    scene.collection.objects.link(light)
    light.rotation_euler = (math.radians(26), math.radians(-22), math.radians(-28))
    sun.color = (1, .88, .72)
    fit = data["camera"]
    yaw, elevation = math.radians(fit["yaw"]), math.radians(fit["elevation"])
    target_pos = transform @ Vector(fit["target"])
    offset = Vector((math.sin(yaw)*math.cos(elevation), math.sin(elevation), math.cos(yaw)*math.cos(elevation))) * fit["distance"]
    camera = bpy.data.cameras.new("ProjectCamera")
    camera.sensor_fit = "VERTICAL"
    camera.lens = camera.sensor_height / (2*math.tan(math.radians(fit["fov"])/2))
    camera.clip_end = 2000
    obj = bpy.data.objects.new("ProjectCamera", camera)
    scene.collection.objects.link(obj)
    obj.location = target_pos + transform @ offset
    obj.rotation_euler = (target_pos-obj.location).to_track_quat("-Z", "Y").to_euler()
    scene.camera = obj
    scene.render.filepath = str(target)
    bpy.ops.wm.save_as_mainfile(filepath=str(target.with_suffix(".blend")))
    bpy.ops.render.render(write_still=True)


def paint_ui(image, tree):
    """Approximate actual GUI rectangles/gradients/icons and Thai text using Pillow.

    Exported instance geometry is retained. Font metrics, border anti-aliasing,
    UIGradient rotation and CoreGui are approximated; no viewport portraits.
    """
    from PIL import Image, ImageDraw, ImageFont

    font_path = "/usr/share/fonts/truetype/noto/NotoSansThai-Regular.ttf"
    fallback = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
    fonts = {}

    def font(size,thai=False):
        size = max(7, round(size))
        key=(size,thai)
        if key not in fonts:
            fonts[key] = ImageFont.truetype(font_path if thai and Path(font_path).exists() else fallback, size)
        return fonts[key]

    def color(value, alpha=1):
        if not value:
            return (255,255,255,round(255*alpha))
        return tuple(round(value.get(channel, 0)*255) for channel in ("r","g","b"))+(round(alpha*255),)

    def udim(value, dimension):
        return value.get("Scale",0)*dimension+value.get("Offset",0)

    def draw_node(node, bounds, inherited_scale=1, forced=None):
        p = node["props"]
        if p.get("Visible") is False:
            return
        class_name = p["ClassName"]
        children = node["children"]
        if class_name in {"ScreenGui", "PlayerGui"}:
            for child in children:
                draw_node(child,bounds,inherited_scale)
            return
        if class_name not in {"Frame","TextLabel","TextButton","ImageLabel","ImageButton","ScrollingFrame","TextBox"}:
            return
        x,y,w,h = bounds
        scale = inherited_scale*next((c["props"]["Scale"] for c in children if c["props"]["ClassName"]=="UIScale"),1)
        s = p.get("Size",{"X":{"Scale":0,"Offset":100},"Y":{"Scale":0,"Offset":100}})
        pos = p.get("Position",{"X":{},"Y":{}})
        nw = s["X"].get("Scale",0)*w+s["X"].get("Offset",0)*scale
        nh = s["Y"].get("Scale",0)*h+s["Y"].get("Offset",0)*scale
        anchor = p.get("AnchorPoint",{})
        nx=x+pos["X"].get("Scale",0)*w+pos["X"].get("Offset",0)*scale-anchor.get("X",0)*nw
        ny=y+pos["Y"].get("Scale",0)*h+pos["Y"].get("Offset",0)*scale-anchor.get("Y",0)*nh
        if forced is not None:
            nx,ny = forced
        if nw<=0 or nh<=0:
            return
        canvas = Image.new("RGBA", image.size)
        d = ImageDraw.Draw(canvas)
        radius = 0
        stroke = None
        for child in children:
            cp = child["props"]
            if cp["ClassName"]=="UICorner":
                radius=min(nw,nh)*cp.get("CornerRadius",{}).get("Scale",0)+cp.get("CornerRadius",{}).get("Offset",0)*scale
            elif cp["ClassName"]=="UIStroke":
                stroke=cp
        alpha=1-p.get("BackgroundTransparency",0)
        if alpha>0:
            gradient=next((c["props"] for c in children if c["props"]["ClassName"]=="UIGradient"),None)
            if gradient and isinstance(gradient.get("Color"),list):
                top,bottom=gradient["Color"][:2]
                patch=Image.new("RGBA",(max(1,round(nw)),max(1,round(nh))))
                pd=ImageDraw.Draw(patch)
                for row in range(patch.height):
                    a=row/max(1,patch.height-1)
                    tint={ch:top.get(ch,0)*(1-a)+bottom.get(ch,0)*a for ch in ("r","g","b")}
                    pd.line((0,row,patch.width,row),fill=color(tint,alpha))
                mask=Image.new("L",patch.size)
                ImageDraw.Draw(mask).rounded_rectangle((0,0,patch.width-1,patch.height-1),radius=radius,fill=255)
                canvas.paste(patch,(round(nx),round(ny)),mask)
            else:
                d.rounded_rectangle((nx,ny,nx+nw,ny+nh),radius=radius,fill=color(p.get("BackgroundColor3"),alpha))
        if stroke:
            d.rounded_rectangle((nx,ny,nx+nw,ny+nh),radius=radius,outline=color(stroke.get("Color"),1-stroke.get("Transparency",0)),width=max(1,round(stroke.get("Thickness",1)*scale)))
        if p.get("Text"):
            text=p["Text"]
            segments=[(part,font(p.get("TextSize",14)*scale,bool(re.match(r"[\u0E00-\u0E7F]",part)))) for part in re.findall(r"[\u0E00-\u0E7F]+|[^\u0E00-\u0E7F]+",text)]
            text_width=sum(d.textlength(part,font=f) for part,f in segments)
            align=p.get("TextXAlignment","Center")
            tx=nx+nw/2 if align=="Center" else nx+nw-3*scale if align=="Right" else nx+3*scale
            tx-=text_width/2 if align=="Center" else text_width if align=="Right" else 0
            stroke_width=1 if p.get("TextStrokeTransparency",1)<.8 else 0
            for part,f in segments:
                d.text((tx,ny+nh/2),part,font=f,fill=color(p.get("TextColor3")),anchor="lm",stroke_width=stroke_width,stroke_fill=color(p.get("TextStrokeColor3")))
                tx+=d.textlength(part,font=f)
        rotation=p.get("Rotation",0)
        if rotation:
            canvas=canvas.rotate(-rotation,resample=Image.Resampling.BICUBIC,center=(nx+nw/2,ny+nh/2))
        image.alpha_composite(canvas)
        layout=next((c["props"] for c in children if c["props"]["ClassName"]=="UIListLayout"),None)
        padding=next((c["props"] for c in children if c["props"]["ClassName"]=="UIPadding"),{})
        left=udim(padding.get("PaddingLeft",{}),nw)*scale
        right=udim(padding.get("PaddingRight",{}),nw)*scale
        top=udim(padding.get("PaddingTop",{}),nh)*scale
        bottom=udim(padding.get("PaddingBottom",{}),nh)*scale
        inner=(nx+left,ny+top,nw-left-right,nh-top-bottom)
        cursor=0
        ordered=sorted(enumerate(children),key=lambda entry:(entry[1]["props"].get("ZIndex",1),entry[0]))
        if layout:
            ordered=sorted(enumerate(children),key=lambda entry:(entry[1]["props"].get("LayoutOrder",0),entry[0]))
        for _,child in ordered:
            cp=child["props"]
            location=None
            if layout and cp["ClassName"] in {"Frame","TextLabel","TextButton","ImageLabel","ImageButton","ScrollingFrame","TextBox"} and cp.get("Visible") is not False:
                horizontal=layout.get("FillDirection")=="Horizontal"
                sz=cp.get("Size",{"X":{},"Y":{}})
                cw=udim(sz["X"],inner[2])*scale
                ch=udim(sz["Y"],inner[3])*scale
                lx=inner[0]+(cursor if horizontal else 0)
                ly=inner[1]+(0 if horizontal else cursor)
                if horizontal and layout.get("VerticalAlignment")=="Center": ly=inner[1]+(inner[3]-ch)/2
                if not horizontal and layout.get("HorizontalAlignment")=="Center": lx=inner[0]+(inner[2]-cw)/2
                location=(lx,ly)
                cursor+=(cw if horizontal else ch)+udim(layout.get("Padding",{}),inner[2] if horizontal else inner[3])*scale
            draw_node(child,inner,scale,location)

    draw_node(tree,(0,58,image.width,image.height-58))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--width",type=int,default=1280)
    parser.add_argument("--height",type=int,default=800)
    parser.add_argument("--luau",default=os.environ.get("LUAU_BIN") or shutil.which("luau") or "/workspace/.roblox-tools/bin/luau")
    parser.add_argument("--blender",default=shutil.which("blender"))
    parser.add_argument("--world-only",action="store_true")
    parser.add_argument("--output",type=Path,default=ROOT/"build/preview/DragonKingdomTycoon-Storybook.png")
    parser.add_argument("--camera-json",type=Path)
    parser.add_argument("--worker",nargs=2,metavar=("SCENE","PNG"),help=argparse.SUPPRESS)
    args=parser.parse_args(sys.argv[sys.argv.index("--")+1:] if "--" in sys.argv else None)
    if args.worker:
        blender_worker(Path(args.worker[0]),Path(args.worker[1]))
        return
    if not args.blender:
        parser.error("Blender is required for this optional offline preview.")
    output=args.output.resolve()
    output.parent.mkdir(parents=True,exist_ok=True)
    paths=["default.project.json","src/models/IslandTemplate.rbxmx","src/shared/DragonArt.luau","src/server/Services/WorldBuilder.luau","src/shared/Engine.luau","src/shared/Domain/Combat.luau","src/shared/Config/Balance.luau","src/shared/Config/Dragons.luau","src/shared/Config/Habitats.luau","src/client/Controllers/Camera.luau","src/client/Controllers/CameraFit.luau","tools/world_smoke.py","tools/visual_preview.py"]
    if not args.world_only: paths.extend(["src/client/Controllers/UI.luau","tests/ui.spec.luau","tools/ui_mock.py"])
    source_hashes={path:hashlib.sha256((ROOT/path).read_bytes()).hexdigest() for path in paths}
    data={"parts":scene_parts(args.luau),"camera":json.loads(args.camera_json.read_text()) if args.camera_json else project_camera(args.luau,args.width,args.height),"width":args.width,"height":args.height}
    scene_file=output.with_suffix(".scene.json")
    scene_file.write_text(json.dumps(data,indent=2)+"\n")
    render_file=output.with_name(output.stem+"-world.png")
    env=dict(os.environ,XDG_CACHE_HOME="/tmp/dragon-preview-cache")
    # Do not rely on or overwrite the user's Blender profile.
    env["BLENDER_USER_CONFIG"]="/tmp/dragon-preview-config"
    log=output.with_suffix(".render.log")
    with log.open("w") as stream:
        result=subprocess.run([args.blender,"--background","--factory-startup","--threads","4","--python-exit-code","1","--python",str(Path(__file__).resolve()),"--","--worker",str(scene_file),str(render_file)],stdout=stream,stderr=subprocess.STDOUT,env=env)
    if result.returncode:
        raise RuntimeError("Blender preview failed; see "+str(log)+"\n"+"\n".join(log.read_text().splitlines()[-20:]))
    from PIL import Image, ImageDraw, ImageFont
    image=Image.new("RGBA",(args.width,args.height))
    draw=ImageDraw.Draw(image)
    for y in range(args.height):
        t=y/args.height
        draw.line((0,y,args.width,y),fill=(round(146+60*t),round(218+20*t),round(244+6*t),255))
    image.alpha_composite(Image.open(render_file).convert("RGBA"))
    if not args.world_only:
        gui=gui_tree(args.luau,args.width,args.height)
        output.with_suffix(".gui.json").write_text(json.dumps(gui,indent=2,ensure_ascii=False)+"\n")
        paint_ui(image,gui)
    draw=ImageDraw.Draw(image)
    font=ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",14)
    # Use the reserved CoreGui strip so provenance never obscures HUD captions.
    draw.rounded_rectangle((10,8,480,48),radius=7,fill=(31,38,47,235))
    draw.text((20,11),"OFFLINE RENDER - NOT ROBLOX STUDIO",font=font,fill=(255,231,171,255))
    draw.text((20,29),"Actual project geometry; approximated materials / GUI",font=font,fill=(244,244,238,255))
    image.convert("RGB").save(output)
    changed=[path for path,sha in source_hashes.items() if hashlib.sha256((ROOT/path).read_bytes()).hexdigest()!=sha]
    if changed:
        output.with_suffix(".metadata.json").unlink(missing_ok=True)
        raise RuntimeError("Preview inputs changed during capture; rerun after sources settle: "+", ".join(changed))
    metadata={"status":"offline_preview_not_studio_screenshot","parts":len(data["parts"]),"shapeCounts":{shape:sum(p["shape"]==shape for p in data["parts"]) for shape in sorted({p["shape"] for p in data["parts"]})},"profile":"Engine.newProfile; no economy or inventory modifications","camera":data["camera"],"sourceHashes":source_hashes,"renderer":"Blender Cycles CPU, 48 samples without denoise; Pillow GUI raster","limitations":["Roblox lighting, material and font rendering are approximated; Color3 display channels converted from sRGB to linear Blender colors.","GUI exported from actual module with mock Roblox instances; CoreGui, viewport portraits and world BillboardGui labels are omitted.","GUI clipping, exact font metrics, shadow edges and animation are approximated or omitted.","Pose is static; animation, streaming, device input, FPS and Roblox runtime behavior are not verified."],"previewSha256":hashlib.sha256(output.read_bytes()).hexdigest()}
    output.with_suffix(".metadata.json").write_text(json.dumps(metadata,indent=2)+"\n")
    print(f"Offline preview rendered: {output}; {len(data['parts'])} actual source parts")


if __name__=="__main__":
    main()
