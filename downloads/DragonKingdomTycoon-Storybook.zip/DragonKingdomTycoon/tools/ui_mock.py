#!/usr/bin/env python3
"""Execute the real Luau UI with explicit headless Roblox stand-ins.

This verifies screen construction and actual Engine action callbacks only. It
cannot certify Roblox rendering, device input, networking, or DataStore behavior.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import shutil
import subprocess
import tempfile


def assembled_source(repo: Path) -> str:
    shared = repo / "src/shared"
    modules: list[str] = []
    for name in ("Dragons", "Habitats", "Balance"):
        source = (shared / "Config" / f"{name}.luau").read_text()
        modules.append(f"local Smoke{name}=(function()\n{source}\nend)()\n")

    combat = (shared / "Domain/Combat.luau").read_text()
    combat = "\n".join(
        line for line in combat.splitlines()
        if not line.startswith(("local Dragons: any =", "local Balance: any ="))
    )
    modules.append(
        "local SmokeCombat=(function()\nlocal Dragons=SmokeDragons;local Balance=SmokeBalance\n"
        + combat + "\nend)()\n"
    )
    engine = (shared / "Engine.luau").read_text()
    engine = "\n".join(
        line for line in engine.splitlines()
        if not (line.startswith("local ") and "require(" in line)
    )
    modules.append(
        "local Engine=(function()\nlocal Dragons=SmokeDragons;local Balance=SmokeBalance;"
        "local Habitats=SmokeHabitats;local Combat=SmokeCombat\n" + engine + "\nend)()\n"
    )

    ui = (repo / "src/client/Controllers/UI.luau").read_text()
    start = ui.index("local Shared =")
    end = ui.index("local UI = {}")
    ui = ui[:start] + (
        "local Dragons=SmokeDragons\nlocal Habitats=SmokeHabitats\nlocal Balance=SmokeBalance\n"
        "local Assets={Icons={},Portraits={},Sounds={}}\n"
        "local DragonArt={build=function() return nil end}\n"
    ) + ui[end:]
    assert ui.rstrip().endswith("return UI"), "UI module export changed; update mock injection"
    ui = ui.rstrip()[:-len("return UI")]
    fixture = (repo / "tests/ui.spec.luau").read_text()
    assert fixture.count("-- @UI_SOURCE_INSERT") == 1
    inputs = (repo / "src/client/Controllers/Input.luau").read_text()
    assert inputs.rstrip().endswith("return Input")
    inputs = inputs.rstrip()[:-len("return Input")]
    assert fixture.count("-- @INPUT_SOURCE_INSERT") == 1
    return fixture.replace("-- @UI_SOURCE_INSERT", "\n".join(modules) + ui).replace("-- @INPUT_SOURCE_INSERT", inputs)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--luau", default=shutil.which("luau"))
    args = parser.parse_args()
    repo = Path(__file__).resolve().parents[1]
    executable = args.luau or "/workspace/.roblox-tools/bin/luau"
    if not Path(executable).is_file() and not shutil.which(executable):
        parser.error("Luau executable missing; provide --luau /path/to/luau")
    with tempfile.TemporaryDirectory(prefix="dragon-ui-mock-") as temporary:
        test = Path(temporary) / "ui-smoke.luau"
        test.write_text(assembled_source(repo))
        return subprocess.run([executable, str(test)], cwd=repo, check=False).returncode


if __name__ == "__main__":
    raise SystemExit(main())
