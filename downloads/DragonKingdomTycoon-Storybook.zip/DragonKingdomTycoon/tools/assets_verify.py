#!/usr/bin/env python3
"""Verify local artwork/audio integrity and explicit missing-asset declarations."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import wave
import numpy as np
from PIL import Image

ROOT=Path(__file__).resolve().parents[1]


def main():
    manifest=json.loads((ROOT/"art/manifest.json").read_text())
    files={}
    for group in ["icons","portraits","sounds","concepts"]:
        for name,entry in manifest[group].items():
            assert not entry["id"], f"Source catalog must not fabricate uploaded IDs: {name}"
            file=ROOT/entry["file"]
            assert file.is_file(),f"Missing local asset: {file}"
            assert hashlib.sha256(file.read_bytes()).hexdigest()==entry["sha256"],f"Source integrity changed: {file}"
            files[file]=entry
    for file,entry in files.items():
        if file.suffix==".png":
            with Image.open(file) as image:
                image.load()
                assert image.size==(entry["width"],entry["height"]),f"Wrong PNG dimensions: {file}"
                if "icons" in file.parts or "portraits" in file.parts:
                    assert image.mode=="RGBA",f"Transparent PNG required: {file}"
                    alpha=np.asarray(image.getchannel("A"))
                    assert np.count_nonzero(alpha==0)>alpha.size*.02,f"No useful transparency: {file}"
                    assert np.count_nonzero(alpha>0)>alpha.size*.10,f"Empty image: {file}"
        elif file.suffix==".wav":
            with wave.open(str(file)) as audio:
                assert audio.getnchannels()==2 and audio.getframerate()==44100 and audio.getsampwidth()==2
                signal=np.frombuffer(audio.readframes(audio.getnframes()),dtype="<i2")
                peak=np.max(np.abs(signal.astype(np.int32)))
                assert 100<peak<32000,f"Silent or clipped WAV: {file}"
    assert len(manifest["icons"])==43
    assert len(manifest["portraits"])==20
    assert len(manifest["sounds"])==8
    assert len(manifest["meshes"])==20
    assert all(not entry["id"] and entry["status"]=="pending_custom_mesh" for entry in manifest["meshes"].values())
    for entry in manifest["portraits"].values():
        x,y=entry["rectOffset"];w,h=entry["rectSize"]
        assert x>=0 and y>=0 and x+w<=entry["width"] and y+h<=entry["height"]
    print(f"PASS: {len(files)} unique original files verified; 20 portrait rectangles valid; 20 custom meshes explicitly pending. Actual Roblox upload and Studio review remain outstanding.")


if __name__=="__main__":
    main()
