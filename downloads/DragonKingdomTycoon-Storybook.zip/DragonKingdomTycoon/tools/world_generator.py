#!/usr/bin/env python3
"""Bake original, asset-independent DEVELOPMENT ART into real Roblox model XML.

Only local procedural geometry is used. This is not an imported custom-mesh art pack.
Regenerate with python3 tools/world_generator.py. Both models are deterministic.
"""
from pathlib import Path
import math
import random
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
RNG = random.Random(41931)
COUNT = 0


def node(parent, cls, name):
    global COUNT
    COUNT += 1
    item = ET.SubElement(parent, 'Item', {'class': cls, 'referent': f'RBX{COUNT}'})
    props = ET.SubElement(item, 'Properties')
    ET.SubElement(props, 'string', {'name': 'Name'}).text = name
    return item, props


def prop(props, cls, name, value):
    ET.SubElement(props, cls, {'name': name}).text = str(value).lower() if isinstance(value, bool) else str(value)


def vector(props, name, xyz):
    element = ET.SubElement(props, 'Vector3', {'name': name})
    for axis, value in zip('XYZ', xyz):
        ET.SubElement(element, axis).text = f'{value:.5f}'


def rotation(rx=0, ry=0, rz=0):
    x, y, z = map(math.radians, (rx, ry, rz))
    cx, sx, cy, sy, cz, sz = math.cos(x), math.sin(x), math.cos(y), math.sin(y), math.cos(z), math.sin(z)
    return (cy*cz, -cy*sz, sy, cx*sz+sx*sy*cz, cx*cz-sx*sy*sz, -sx*cy, sx*sz-cx*sy*cz, sx*cz+cx*sy*sz, cx*cy)


def part(parent, name, pos, size, color, shape='Ball', rot=(0, 0, 0), material=272, transparency=0, collide=False):
    item, props = node(parent, 'Part' if shape != 'Wedge' else 'WedgePart', name)
    vector(props, 'Size', size)
    cf = ET.SubElement(props, 'CoordinateFrame', {'name': 'CFrame'})
    for key, value in zip(('X', 'Y', 'Z', 'R00', 'R01', 'R02', 'R10', 'R11', 'R12', 'R20', 'R21', 'R22'), (*pos, *rotation(*rot))):
        ET.SubElement(cf, key).text = f'{value:.6f}'
    rgb = tuple(int(color.strip('#')[i:i+2], 16)/255 for i in (0, 2, 4))
    col = ET.SubElement(props, 'Color3', {'name': 'Color'})
    for channel, value in zip(('R', 'G', 'B'), rgb):
        ET.SubElement(col, channel).text = f'{value:.6f}'
    prop(props, 'bool', 'Anchored', True)
    prop(props, 'bool', 'CanCollide', collide)
    prop(props, 'bool', 'CanTouch', False)
    prop(props, 'bool', 'CanQuery', True)
    prop(props, 'bool', 'CastShadow', transparency < .5)
    prop(props, 'float', 'Transparency', transparency)
    prop(props, 'token', 'Material', material)
    prop(props, 'token', 'TopSurface', 0)
    prop(props, 'token', 'BottomSurface', 0)
    if shape != 'Wedge':
        prop(props, 'token', 'shape', {'Ball': 0, 'Block': 1, 'Cylinder': 2}[shape])
    return item


def model(parent, name):
    return node(parent, 'Model', name)[0]


def orb(parent, name, p, s, c, **kw):
    return part(parent, name, p, s, c, **kw)


def disc(parent, name, p, radius, height, color, **kw):
    return part(parent, name, p, (height, radius*2, radius*2), color, 'Cylinder', (0, 0, 90), **kw)


def beam(parent, name, a, b, radius, color, material=272):
    midpoint = tuple((x+y)/2 for x, y in zip(a, b))
    d = tuple(y-x for x, y in zip(a, b))
    length = math.sqrt(sum(x*x for x in d))
    # Cylinder axis X. Direction gives yaw and pitch.
    yaw = -math.degrees(math.atan2(d[2], d[0]))
    pitch = math.degrees(math.atan2(d[1], math.hypot(d[0], d[2])))
    return part(parent, name, midpoint, (length, radius*2, radius*2), color, 'Cylinder', (0, yaw, pitch), material)


def tree(parent, x, z, scale=1, color='39BC69', y=0):
    m = model(parent, 'WhorlleafTree')
    # An exposed, flared root system and interlocking shaded crowns read as a
    # leafy storybook tree from the gameplay camera without external meshes.
    beam(m, 'RoundedTrunk', (x, y+.1, z), (x+.45*scale, y+6.4*scale, z), 1.0*scale, '81502D', 512)
    beam(m, 'TrunkSunlitBark', (x-.35*scale,y+.5,z-.35*scale), (x+.1*scale,y+6.3*scale,z-.35*scale), .35*scale, 'BB8040', 512)
    for k in (-1, 1):
        beam(m, 'Fork', (x+.4*scale, y+4.2*scale, z), (x+k*2.4*scale, y+8.1*scale, z), .48*scale, '916038', 512)
    shades = ['24864A', color, '83CD53', '48AB47', 'A7DF6A']
    for i,(dx, dy, dz, radius) in enumerate([(-2.1,7.4,0,3.1),(2.2,8.0,.4,3.2),(0,10.0,.5,3.2),(0,8.0,-2.4,3.0),(-2.1,10.0,-1.2,2.2),(2,10.6,-1,2.1),(.2,11.9,0,2.3),(-.3,9.3,2.5,2.5)]):
        orb(m, 'LeafCrown', (x+dx*scale,y+dy*scale,z+dz*scale), (radius*2*scale, radius*1.6*scale, radius*2*scale), shades[i%len(shades)])
    for k in range(5):
        a=k*math.tau/5
        beam(m, 'Root', (x,y+.7*scale,z), (x+math.cos(a)*2.4*scale,y+.14,z+math.sin(a)*2.4*scale), .48*scale, '996336', 512)
    for k in range(3):
        a=k*2.1+.8
        orb(m,'RootMoss',(x+math.cos(a)*1.9*scale,y+.3,z+math.sin(a)*1.9*scale),(1.8*scale,.45,1.6*scale),'77B84E')


def flower(parent, x, z, color='FFB7DA', scale=1, y=0):
    m = model(parent, 'StarbellFlowers')
    beam(m, 'Stem', (x,y,z), (x,y+1.2*scale,z), .11*scale, '419B5B')
    for k in range(5):
        angle = k*math.tau/5
        orb(m, 'Petal', (x+math.cos(angle)*.4*scale,y+1.2*scale,z+math.sin(angle)*.4*scale), (.7*scale,.3*scale,.7*scale), color)
    orb(m,'Pollen',(x,y+1.35*scale,z),(.35*scale,.25*scale,.35*scale),'FFE886')


def roof(parent, x, y, z, radius, color):
    # A stack of curved, scalloped eaves, a golden finial, and ribs.
    for tier in range(4):
        r = radius*(1-tier*.18)
        orb(parent,'CurvedRoofTier',(x,y+tier*1.15,z),(r*2,2.0,r*2),color)
    for k in range(8):
        a = k*math.tau/8
        orb(parent,'RoofScallop',(x+math.cos(a)*radius*.78,y-.2,z+math.sin(a)*radius*.78),(3.0,1.25,3.0),'F4C971')
    orb(parent,'GoldenFinial',(x,y+4.3,z),(1.2,2.0,1.2),'FFE49A',material=1088)


def pavilion(parent, kind, x, z, roof_color, radius=8):
    m = model(parent, kind)
    disc(m,'Foundation',(x,.5,z),radius+2,1.3,'EEE2B9',collide=True)
    disc(m,'InlaidFloor',(x,1.25,z),radius, .3,'BF93BD')
    for k in range(6):
        a = k*math.tau/6
        px,pz=x+math.cos(a)*radius*.78,z+math.sin(a)*radius*.78
        disc(m,'ColumnFoot',(px,1.8,pz),1.0,.55,'F2CF7A')
        beam(m,'IvoryColumn',(px,2,pz),(px,8,pz),.55,'FFEFD6')
        disc(m,'ColumnCapital',(px,8,pz),1.0,.55,'E6B95E')
    roof(m,x,9,z,radius+1,roof_color)
    for step in range(3):
        orb(m,'RoundedEntranceStep',(x,1.15-step*.4,z+radius+1+step*1.3),(6,.7,3),'ECDDBA',collide=True)
    return m


def cottage(parent, name, x, z, roof_color='D98749', scale=1):
    """Small timber-and-plaster buildings with dimensional doors/windows."""
    m=model(parent,name)
    part(m,'CottageStoneFooting',(x,.7,z),(7.8*scale,1.4,6.2*scale),'BB9A63','Block')
    part(m,'WarmPlasterWalls',(x,3.1*scale,z),(7*scale,4.8*scale,5.5*scale),'F7DF9A','Block')
    for side in (-1,1):
        part(m,'TimberCorner',(x+side*3.2*scale,3.0*scale,z-2.65*scale),(.5*scale,5*scale,.5*scale),'82512E','Block')
        part(m,'SlopingTileRoof',(x+side*2.0*scale,6.0*scale,z),(4.9*scale,.75*scale,7.3*scale),roof_color,'Block',(0,0,side*32))
        for row in range(3):
            part(m,'RoofTileBand',(x+side*(.85+row*.78)*scale,(6.8-row*.49)*scale,z),(1.0*scale,.25*scale,7.5*scale),'E9A663','Block',(0,0,side*32))
    beam(m,'RoofRidge',(x,7.1*scale,z-3.8*scale),(x,7.1*scale,z+3.8*scale),.23*scale,'78452A',512)
    part(m,'CottageDoor',(x,2.2*scale,z+2.82*scale),(1.8*scale,3.1*scale,.22),'925A37','Block')
    orb(m,'DoorHandle',(x+.58*scale,2.1*scale,z+3.0*scale),(.24,.24,.24),'F9D067')
    for side in (-1,1):
        part(m,'WindowFrame',(x+side*2.15*scale,3.1*scale,z+2.86*scale),(1.45*scale,1.6*scale,.2),'885C33','Block')
        part(m,'WindowWarmGlass',(x+side*2.15*scale,3.1*scale,z+3.0*scale),(1.12*scale,1.25*scale,.12),'FFF3B6','Block')
        part(m,'WindowCrossbar',(x+side*2.15*scale,3.1*scale,z+3.1*scale),(.13,1.3*scale,.1),'9B6539','Block')
    part(m,'BrickChimney',(x+2*scale,7.3*scale,z-1.7*scale),(1.2*scale,3*scale,1.2*scale),'BA7953','Block')
    orb(m,'CottageEntranceStep',(x,.6,z+3.4*scale),(3.3*scale,.8,1.8*scale),'E5C58B')
    return m


def bridge(parent, x, z, length=18, angle=0, wood=True):
    m=model(parent,'WillowBridge' if wood else 'MoonstoneBridge')
    def point(dx,dy,dz):
        a=math.radians(angle)
        return (x+dx*math.cos(a)+dz*math.sin(a),dy,z-dx*math.sin(a)+dz*math.cos(a))
    for k in range(int(length/1.6)):
        dz=-length/2+(k+.5)*1.6
        p=point(0,1.1+math.sin((dz/length+.5)*math.pi)*2,dz)
        part(m,'CarvedPlank',p,(7,.6,1.45),'BC8752' if wood else 'CBD9E6','Block',(0,angle,0),512 if wood else 800,collide=True)
    for side in (-1,1):
        for k in range(5):
            dz=-length/2+k*length/4
            base=1.1+math.sin((dz/length+.5)*math.pi)*2
            beam(m,'RoundRailPost',point(side*3.7,base,dz),point(side*3.7,base+2.5,dz),.23,'795139' if wood else 'CAD9EF',512 if wood else 800)
            if k:
                prev=-length/2+(k-1)*length/4
                ph=1.1+math.sin((prev/length+.5)*math.pi)*2
                beam(m,'CurvedRail',point(side*3.7,ph+2.4,prev),point(side*3.7,base+2.4,dz),.22,'D8AF70' if wood else 'E5EDF7')
    return m


def island(parent, offset=(0,0,0), showcase=False):
    xoff,yoff,zoff=offset
    m=model(parent,'IslandTemplate' if not showcase else 'ArrivalIsland')
    pivot=part(m,'IslandOrigin',(0,0,0),(1,1,1),'FFFFFF',transparency=1)
    prop(m.find('Properties'),'Ref','PrimaryPart',pivot.attrib['referent'])
    # Geometry starts local. Offset applied at the end, preserving a valid default pivot.
    terrain=model(m,'SculptedFloatingTerrain')
    disc(terrain,'NaturalGrassCanopy',(0,-.9,0),74,1.8,'91D75B',material=1280,collide=True)
    disc(terrain,'OchreTopsoil',(0,-2.6,0),73,2.5,'C19A52')
    disc(terrain,'FloatingRockMass',(0,-13.0,0),68,22,'825734',material=512)
    orb(terrain,'TaperedUnderside',(1,-29,0),(126,27,121),'795130',material=512)
    orb(terrain,'FloatingKeel',(3,-39,2),(79,19,74),'614627',material=512)
    # Vertical cliff ribs and hanging grass replace the gray boulder stack.
    # Only the original plateau supplies collision; ornament is collision-free.
    for k in range(29):
        angle=k*math.tau/29
        rad=68+RNG.uniform(-2,3)
        x,z=math.cos(angle)*rad,math.sin(angle)*rad
        depth=RNG.uniform(29,38)
        orb(terrain,'RoundedCliffStratum',(x,-3.2-depth*.5,z),(RNG.uniform(11,16),depth,RNG.uniform(10,15)),RNG.choice(['A77542','B98C50','8C6039','966A3D']),material=512)
        orb(terrain,'CliffSunlitRib',(x*.998,-16-RNG.random()*4,z*.998),(4.8,23,4.8),'BB8C4E',material=512)
        orb(terrain,'GrassOverhang',(x*.99,-.65,z*.99),(RNG.uniform(12,17),2.8,RNG.uniform(12,17)),RNG.choice(['7FC751','9BDB5C','65B94B']),material=1280)
        if k%3==0:
            beam(terrain,'HangingTreeRoot',(x*.97,-3,z*.97),(x*.96,-23,z*.96),.55,'705132',512)
    for k in range(96):
        angle=k*math.tau/96
        rad=72.2+1.1*math.sin(k*.8)
        x,z=math.cos(angle)*rad,math.sin(angle)*rad
        length=RNG.uniform(3.8,7.1)
        part(terrain,'HangingGrassFringe',(x,-length*.38,z),(RNG.uniform(1.6,3.0),length,2.7),RNG.choice(['528C38','65A13F','7ABC43','3F8135']),'Wedge',(-21,90-math.degrees(angle),180),material=1280)
    for k in range(9):
        x,z=RNG.uniform(-35,35),RNG.uniform(-30,30)
        orb(terrain,'UndersideCrystal',(x,-36-RNG.random()*7,z),(2,6,2),'93D6D7',material=288)

    landscape=model(m,'LivingLandscape')
    for x,z,s,c in [(-65,-23,1,'50A841'),(-65,6,.8,'5CB440'),(-55,39,1.1,'43A34A'),(-28,57,.8,'56AF45'),(55,35,.8,'5AB447'),(66,3,.9,'3F9E47'),(61,-21,1,'62B34B'),(26,-57,.95,'78BF5A'),(-15,-60,.8,'50A847'),(-48,-48,.75,'68B743'),(5,60,.85,'5DB249'),(48,48,.7,'4AA749')]:
        tree(landscape,x,z,s,c)
    for k in range(40):
        a=RNG.random()*math.tau
        rad=RNG.uniform(57,67)
        x,z=math.cos(a)*rad,math.sin(a)*rad
        orb(landscape,'FernBush',(x,.8,z),(RNG.uniform(2.2,4.5),RNG.uniform(1.5,2.8),RNG.uniform(2.2,4.5)),RNG.choice(['3F9C3F','5DAE40','9ECF55']))
        if k%2==0:
            flower(landscape,x+2,z, RNG.choice(['FFD773','FFB0D0','C9B2FF','F2F5FF']),.8)
    # Winding stepping-stone promenade stays away from placement rectangles.
    for k in range(28):
        x=-48+k*3.7
        z=39+3*math.sin(k*.32)
        orb(landscape,'PolishedPathStone',(x,.3,z),(3.3,.6,2.8),'E5DDBA',collide=True)
    for k in range(10):
        orb(landscape,'HatcheryPath',(-29+math.sin(k*.5)*2,.25,-29-k*1.4),(3.3,.5,2.4),'E5DDBA')

    water=model(m,'MoonwaterGarden')
    orb(water,'PondRockBed',(-49,.4,23),(27,1.5,23),'BFAE71')
    orb(water,'DeepTurquoisePond',(-49,1.05,23),(23,.45,19),'31BBD0',material=1568,transparency=.12)
    orb(water,'PoolGleam',(-49,1.2,23),(20,.15,16),'74F0DF',material=1568,transparency=.38)
    for k in range(12):
        a=k*math.tau/12
        radius=1+.08*math.sin(k*2.1)
        orb(water,'WaterWornStone',(-49+math.cos(a)*12*radius,.8,23+math.sin(a)*10*radius),(3.3,2,2.6),'DAD1A3')
    for k in range(13):
        z=31+k*2.65
        x=-48+math.sin(k*.4)*4
        orb(water,'StreamBank',(x,.3,z),(8,1,5),'92CBA1')
        orb(water,'BendingStream',(x,.9,z),(5.3,.3,4.2),'75E7EA',material=1568,transparency=.2)
    bridge(water,-45,43,16,0)
    for k in range(4):
        orb(water,'WaterfallRibbon',(-47+k*1.25,-14+math.sin(k)*2,66),(1.8,32,1.15),'7CDDE9',material=1568,transparency=.26)
        orb(water,'FallingWaterFoam',(-47+k*1.25,-29,66),(2.8,1.5,2.8),'EBFFFF',transparency=.12)
    for k in range(4):
        orb(water,'LilyPad',(-54+k*3,1.5,18+k%2*4),(2,.15,2),'39A568')
        flower(water,-54+k*3,18+k%2*4,'FFCADF',.5,1.5)

    buildings=model(m,'FoundersTerrace')
    hatch=pavilion(buildings,'Hatchery',-29,-43,'438ECB',8)
    orb(hatch,'NestBowl',(-29,2.4,-43),(7,2,7),'E0B35C')
    orb(hatch,'WelcomeEgg',(-29,4,-43),(3.0,4.1,3.0),'DAF1FF')
    for k in range(5):
        orb(hatch,'EggGoldenSpot',(-29+math.sin(k*2.1)*1.1,3.3+k*.3,-44),(0.55,.5,.2),'F8CE69')
    breed=pavilion(buildings,'Breeding',3,-43,'BD69BC',7.5)
    orb(breed,'SanctuaryHeart',(3,4,-43),(2.9,2.9,1.3),'FF9DC8',material=288)
    for k in range(6):
        flower(breed,3+math.cos(k)*6,-43+math.sin(k)*6,'E4B1F4',1.0,1.4)

    farm=model(buildings,'Farmstead')
    disc(farm,'GardenBorder',(49,1,-40),11,1.4,'CCAE6C',collide=True)
    part(farm,'PloughedBed',(49,1.8,-40),(14,.5,12),'805E43','Block',material=512)
    for row in range(3):
        for col in range(4):
            x,z=43+col*3.5,-44+row*4
            orb(farm,'EmeraldCropLeaf',(x,2.7,z),(2,2.8,1.5),'6FC95B',rot=(0,col*19,20))
            orb(farm,'Sunberry',(x,2.6,z+.6),(1.1,1.2,1.1),'FFB753')
    roof(farm,49,6,-48,5,'51A273')
    beam(farm,'FarmRoofPost',(44,1,-48),(44,6,-48),.4,'D5BB85')
    beam(farm,'FarmRoofPost',(54,1,-48),(54,6,-48),.4,'D5BB85')
    cottage(farm,'OrchardCottage',43,-53,'C87743',.95)
    cottage(buildings,'KeepersCottage',-50,-43,'9A8649',.8)
    for k in range(5):
        orb(farm,'FarmCottagePath',(49-k*1.2,.28,-47-k*1.2),(2.7,.56,2.5),'E2CC8C')

    arena=model(buildings,'Arena')
    disc(arena,'ArenaGoldPlinth',(29,1.4,43),13,2.8,'CFB578',collide=True)
    disc(arena,'ArenaInlay',(29,3,43),11,.4,'757CBC')
    disc(arena,'ArenaMoonRing',(29,3.3,43),8,.15,'AADDDD')
    disc(arena,'ArenaFloor',(29,3.4,43),7,.2,'7986AB')
    for k in range(8):
        a=k*math.tau/8
        px,pz=29+math.cos(a)*12,43+math.sin(a)*12
        beam(arena,'ArenaColumn',(px,2,pz),(px,7,pz),.6,'F2E1BC')
        orb(arena,'ArenaCrystal',(px,8,pz),(1.3,2.4,1.3),'ADE8EE',material=288)

    clouds=model(m,'CloudBank')
    for k in range(15):
        a=k*math.tau/15
        rad=RNG.uniform(95,125)
        x,z=math.cos(a)*rad,math.sin(a)*rad
        for j in range(3):
            orb(clouds,'CloudPuff',(x+j*7,-25-RNG.uniform(0,16),z),(RNG.uniform(20,32),RNG.uniform(10,16),RNG.uniform(15,25)),'FFFDE8',transparency=.13)
    if showcase:
        for x,c,name in [(-35,'FF9654','Emberhaven'),(5,'6CDDE9','Tidehaven'),(45,'8BCD66','Bloomhaven')]:
            h=model(m,name)
            disc(h,'GoldenHabitatRim',(x,1,5),10,1.5,'DCC088')
            disc(h,'ElementalBed',(x,1.9,5),8.7,.45,c)
            # Display-only original rounded creatures are baked for edit-mode inspection.
            d=model(h,'DevelopmentDragon')
            orb(d,'PearTorso',(x,4.5,5),(4,4.5,5),c)
            orb(d,'RoundedHead',(x,7,2.5),(3.6,3.4,3.7),c)
            orb(d,'Muzzle',(x,6.5,.8),(2.6,1.7,2),'FFEEBF')
            for side in (-1,1):
                orb(d,'Eye',(x+side*1.25,7.3,1.25),(.85,1,.4),'FFF9E3')
                orb(d,'Pupil',(x+side*1.25,7.25,1.05),(.4,.6,.23),'384263')
                orb(d,'Horn',(x+side*1.1,9,2.7),(.7,2,.7),'F9D986',rot=(0,0,side*16))
                orb(d,'Wing',(x+side*3.5,6.3,5),(4.4,.6,3),'F5D58D',rot=(0,side*15,side*25))
                orb(d,'Foot',(x+side*1.4,2.5,3.8),(1.4,1.3,2.4),c)
                orb(d,'Arm',(x+side*2,4.8,3.4),(1.1,2.2,1.1),c,rot=(0,0,side*20))
            for k in range(5):
                orb(d,'CurledTail',(x+math.sin(k*.5)*2,3.1+k*.16,7+k*1.2),(1.5-k*.2,1.5-k*.2,2.0-k*.2),c)
    if any(offset):
        for cf in m.findall('.//CoordinateFrame'):
            for axis, off in zip('XYZ',offset):
                cf.find(axis).text=f'{float(cf.find(axis).text)+off:.6f}'
    return m


def document():
    root=ET.Element('roblox',{'xmlns:xmime':'http://www.w3.org/2005/05/xmlmime','xmlns:xsi':'http://www.w3.org/2001/XMLSchema-instance','version':'4'})
    ET.SubElement(root,'External').text='null'
    ET.SubElement(root,'External').text='nil'
    return root


def save(root,path):
    ET.indent(root,space='  ')
    path.parent.mkdir(parents=True,exist_ok=True)
    ET.ElementTree(root).write(path,encoding='utf-8',xml_declaration=True)
    parts=len(root.findall('.//Item[@class="Part"]'))
    print(f'{path.relative_to(ROOT)}: {parts} anchored parts, {path.stat().st_size:,} bytes')


if __name__=='__main__':
    template=document()
    island(template)
    save(template,ROOT/'src/models/IslandTemplate.rbxmx')
    world=document()
    container=model(world,'World')
    island(container,(0,80,0),True)
    save(world,ROOT/'src/world/World.rbxmx')
