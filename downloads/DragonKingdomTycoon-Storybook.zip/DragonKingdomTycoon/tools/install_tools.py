#!/usr/bin/env python3
"""Install SHA256-pinned official Linux tools without root or repository edits."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import shlex
import subprocess
import tempfile
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def atomic_write(path, data, mode=0o644):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as stream:
            temporary = Path(stream.name)
            stream.write(data)
        temporary.chmod(mode)
        os.replace(temporary, path)
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prefix', type=Path, default=ROOT / '.tools')
    parser.add_argument('--cache-dir', type=Path, help='Optional verified release archive cache')
    args = parser.parse_args()
    if (platform.system(), platform.machine()) != ('Linux', 'x86_64'):
        parser.error('This lockfile supports Linux x86_64; use official matching tools on Windows/macOS.')
    lock = json.loads((ROOT / 'toolchain.lock.json').read_text())
    prefix = args.prefix.resolve()
    marker = prefix / 'installed.json'
    if prefix.exists() and any(prefix.iterdir()) and not marker.is_file():
        parser.error(f'Refusing to modify an existing unmanaged directory: {prefix}')
    prefix.mkdir(parents=True, exist_ok=True)
    cache = (args.cache_dir or prefix / 'downloads').resolve()
    cache.mkdir(parents=True, exist_ok=True)
    bindir = prefix / 'bin'
    bindir.mkdir(exist_ok=True)
    # Mark the dedicated prefix before installing so interrupted runs can resume.
    atomic_write(marker, (json.dumps(lock, indent=2) + '\n').encode())
    for release in lock['releases']:
        archive = cache / release['archive']
        if not archive.exists():
            request = urllib.request.Request(release['url'], headers={'User-Agent': 'DragonKingdom-toolchain'})
            with urllib.request.urlopen(request, timeout=60) as response:
                data = response.read()
            if hashlib.sha256(data).hexdigest() != release['sha256']:
                raise RuntimeError(f'Download checksum mismatch: {release["name"]}')
            atomic_write(archive, data)
        if digest(archive) != release['sha256']:
            raise RuntimeError(f'Cached archive checksum mismatch: {archive}')
        destination = prefix / (release['name'] + '-' + release['version'])
        with zipfile.ZipFile(archive) as package:
            for name in release['binaries']:
                # Only read the named release binaries; never extract arbitrary paths.
                binary = destination / name
                atomic_write(binary, package.read(name), 0o755)
                link = bindir / name
                if link.is_symlink():
                    if not link.resolve().is_relative_to(prefix):
                        raise RuntimeError(f'Refusing an unmanaged symlink: {link}')
                    link.unlink()
                elif link.exists():
                    raise RuntimeError(f'Refusing to replace a non-symlink: {link}')
                link.symlink_to(binary)
        print(f'{release["name"]} {release["version"]}: verified and installed', flush=True)
    atomic_write(prefix / 'activate', ('export PATH=' + shlex.quote(str(bindir)) + ':"$PATH"\n').encode())
    version = subprocess.check_output([str(bindir / 'rojo'), '--version'], text=True).strip()
    assert version == 'Rojo 7.7.1', version
    with tempfile.TemporaryDirectory(prefix='dragon-toolchain-') as directory:
        test = Path(directory) / 'check.luau'
        test.write_text('--!strict\nlocal values: {number} = {2, 3}\nassert(values[1] + values[2] == 5)\nprint("Luau runtime verified")\n')
        subprocess.run([str(bindir / 'luau-analyze'), str(test)], check=True)
        subprocess.run([str(bindir / 'luau'), str(test)], check=True)
    print(f'{version}; source {prefix / "activate"}')


if __name__ == '__main__':
    main()
